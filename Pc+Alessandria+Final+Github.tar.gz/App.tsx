import { useEffect, useMemo, useRef, useState } from "react";
import logoUrl from "container:///mnt/data/src/assets/739202fb338e864d-Protezione_Civile_Logo";
import "./index.css";

type Ruolo = "volontario" | "coordinatore" | "servizio";
type Volontario = {
  id: string;
  nome: string;
  cognome: string;
  cf: string;
  telefono: string;
  email: string;
  qualifica: string;
  stato: "attivo" | "sospeso";
  pin: string;
  ruolo: Ruolo;
};
type Timbratura = {
  id: string;
  volontarioId: string;
  tipo: "normale" | "emergenza";
  timestampIn: string;
  timestampOut?: string;
  latIn: number;
  lonIn: number;
  distanza?: number;
  latOut?: number;
  lonOut?: number;
  resoconto?: string;
  validata?: boolean;
  posizioniEmergenza?: { lat: number; lon: number; timestamp: string }[];
};
type Ferie = { id: string; volontarioId: string; inizio: string; fine: string; motivo: string; stato: "in_attesa" | "approvata" | "rifiutata" };
type Reperibilita = { id: string; volontarioId: string; data: string; dalle: string; alle: string; note?: string };
type ChatMsg = { id: string; canale: "Generale" | "Emergenze" | "Coordinamento"; volontarioId: string; nome: string; testo: string; timestamp: string };
type Allerta = { id: string; titolo: string; messaggio: string; livello: "info" | "allerta" | "emergenza"; timestamp: string; mittenteId: string };

const SEDE = { lat: 44.897036, lon: 8.597517, indirizzo: "Strada Casalcermelli 49C, 15121 Alessandria (AL)" };
const RAGGIO_METRI = 150;
const DEFAULT_VOLONTARI: Volontario[] = [
  { id: "v1", nome: "Mario", cognome: "Rossi", cf: "RSSMRA80A01A001A", telefono: "333 1234567", email: "mario.rossi@pc-alessandria.it", qualifica: "Volontario Operativo", stato: "attivo", pin: "1234", ruolo: "volontario" },
  { id: "v2", nome: "Luca", cognome: "Verdi", cf: "VRDLCA85B02A002B", telefono: "333 2345678", email: "luca.verdi@pc-alessandria.it", qualifica: "Autista Mezzi", stato: "attivo", pin: "2345", ruolo: "volontario" },
  { id: "v3", nome: "Giulia", cognome: "Neri", cf: "NREGLI90C03A003C", telefono: "333 3456789", email: "giulia.neri@pc-alessandria.it", qualifica: "Logistica", stato: "attivo", pin: "3456", ruolo: "volontario" },
  { id: "v4", nome: "Coordinatore", cognome: "Bianchi", cf: "BNCCRD75D04A004D", telefono: "333 4567890", email: "coordinatore@pc-alessandria.it", qualifica: "Coordinatore", stato: "attivo", pin: "9999", ruolo: "coordinatore" },
  { id: "v5", nome: "Servizio", cognome: "Comunale", cf: "CMNSRV70E05A005E", telefono: "0131 123456", email: "protezione.civile@comune.alessandria.it", qualifica: "Servizio Comunale", stato: "attivo", pin: "0000", ruolo: "servizio" },
];

function haversine(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371e3;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}
function fmtDate(iso: string) {
  return new Date(iso).toLocaleString("it-IT", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
}
function fmtOnlyDate(iso: string) {
  return new Date(iso).toLocaleDateString("it-IT");
}
function diffHours(start: string, end?: string) {
  if (!end) return 0;
  return (new Date(end).getTime() - new Date(start).getTime()) / 3600000;
}
function genPin() {
  return Math.floor(1000 + Math.random() * 9000).toString();
}

async function api(action: string, args: any) {
  const res = await fetch("actions", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action, args }) });
  const j = await res.json();
  if (!res.ok || j.error) throw new Error(j.error || "Errore API");
  return j.data;
}
const records = {
  list: (collection: string, limit?: number) => api("records.list", { collection, limit }),
  create: (collection: string, value: any, idempotency_key?: string) => api("records.create", { collection, value, idempotency_key }),
  replace: (collection: string, id: string, value: any) => api("records.replace", { collection, id, value }),
  delete: (collection: string, id: string) => api("records.delete", { collection, id }),
  get: (collection: string, id: string) => api("records.get", { collection, id }),
};

export default function App() {
  const [currentUser, setCurrentUser] = useState<Volontario | null>(null);
  const [loginId, setLoginId] = useState<string>("v1");
  const [pinInput, setPinInput] = useState("");
  const [showPin, setShowPin] = useState(false);
  const [loginError, setLoginError] = useState("");

  const [volontari, setVolontari] = useState<Volontario[]>(DEFAULT_VOLONTARI);
  const [timbrature, setTimbrature] = useState<Timbratura[]>([]);
  const [ferie, setFerie] = useState<Ferie[]>([]);
  const [reperibilita, setReperibilita] = useState<Reperibilita[]>([]);
  const [chat, setChat] = useState<ChatMsg[]>([]);
  const [allerte, setAllerte] = useState<Allerta[]>([]);
  const [loading, setLoading] = useState(true);
  const [apiError, setApiError] = useState<string | null>(null);

  const [tab, setTab] = useState<string>("home");
  const [toast, setToast] = useState<string | null>(null);
  const [geoStatus, setGeoStatus] = useState<"idle" | "locating" | "ok" | "error">("idle");
  const [lastPos, setLastPos] = useState<{ lat: number; lon: number; dist: number } | null>(null);
  const [resoconto, setResoconto] = useState("");
  const [ferieForm, setFerieForm] = useState({ inizio: "", fine: "", motivo: "" });
  const [repForm, setRepForm] = useState({ data: "", dalle: "08:00", alle: "20:00", note: "" });
  const [chatCanale, setChatCanale] = useState<ChatMsg["canale"]>("Generale");
  const [chatTesto, setChatTesto] = useState("");
  const [volForm, setVolForm] = useState<Partial<Volontario> & { id?: string }>({});
  const [showVolModal, setShowVolModal] = useState(false);
  const [showVolPin, setShowVolPin] = useState<Record<string, boolean>>({});
  const [allertaForm, setAllertaForm] = useState({ titolo: "", messaggio: "", livello: "allerta" as Allerta["livello"] });
  const [schedFilter, setSchedFilter] = useState<{ mese: number; anno: number; volontarioId: string }>({
    mese: new Date().getMonth(),
    anno: new Date().getFullYear(),
    volontarioId: "all",
  });
  const [selectedDayDetail, setSelectedDayDetail] = useState<Timbratura | null>(null);
  const [emergencyCountdown, setEmergencyCountdown] = useState<number>(30);
  const [emergencyActiveId, setEmergencyActiveId] = useState<string | null>(null);
  const emergencyTimerRef = useRef<number | null>(null);
  const emergencyCountRef = useRef<number | null>(null);

  const isCoord = currentUser?.ruolo === "coordinatore" || currentUser?.ruolo === "servizio";

  useEffect(() => {
    (async () => {
      try {
        const [v, t, f, r, c, a] = await Promise.all([
          records.list("pc_volontari", 100).catch(() => ({ records: [] })),
          records.list("pc_timbrature", 100).catch(() => ({ records: [] })),
          records.list("pc_ferie", 100).catch(() => ({ records: [] })),
          records.list("pc_reperibilita", 100).catch(() => ({ records: [] })),
          records.list("pc_chat", 100).catch(() => ({ records: [] })),
          records.list("pc_allerte", 100).catch(() => ({ records: [] })),
        ]);
        if (v.records?.length) setVolontari(v.records.map((x: any) => x.value));
        else {
          for (const dv of DEFAULT_VOLONTARI) {
            try { await records.create("pc_volontari", dv, `seed-${dv.id}`); } catch {}
          }
        }
        if (t.records?.length) setTimbrature(t.records.map((x: any) => x.value).sort((a: any, b: any) => new Date(b.timestampIn).getTime() - new Date(a.timestampIn).getTime()));
        if (f.records?.length) setFerie(f.records.map((x: any) => x.value));
        if (r.records?.length) setReperibilita(r.records.map((x: any) => x.value));
        if (c.records?.length) setChat(c.records.map((x: any) => x.value).sort((a: any, b: any) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()));
        if (a.records?.length) setAllerte(a.records.map((x: any) => x.value).sort((a: any, b: any) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()));
        setApiError(null);
      } catch (e: any) {
        setApiError(e.message || "API non disponibile in anteprima");
        const ls = (k: string) => { try { return JSON.parse(localStorage.getItem(k) || "[]"); } catch { return []; } };
        const vls = ls("pc_volontari");
        if (vls.length) setVolontari(vls);
        setTimbrature(ls("pc_timbrature"));
        setFerie(ls("pc_ferie"));
        setReperibilita(ls("pc_reperibilita"));
        setChat(ls("pc_chat"));
        setAllerte(ls("pc_allerte"));
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem("pc_volontari", JSON.stringify(volontari));
      localStorage.setItem("pc_timbrature", JSON.stringify(timbrature));
      localStorage.setItem("pc_ferie", JSON.stringify(ferie));
      localStorage.setItem("pc_reperibilita", JSON.stringify(reperibilita));
      localStorage.setItem("pc_chat", JSON.stringify(chat));
      localStorage.setItem("pc_allerte", JSON.stringify(allerte));
    } catch {}
  }, [volontari, timbrature, ferie, reperibilita, chat, allerte]);

  useEffect(() => {
    const manifest = {
      name: "Protezione Civile Alessandria",
      short_name: "PC Alessandria",
      start_url: ".",
      display: "standalone",
      background_color: "#0f2c5c",
      theme_color: "#0f2c5c",
      icons: [{ src: logoUrl, sizes: "192x192", type: "image/png" }],
    };
    const blob = new Blob([JSON.stringify(manifest)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    let link = document.querySelector('link[rel="manifest"]') as HTMLLinkElement | null;
    if (!link) {
      link = document.createElement("link");
      link.rel = "manifest";
      document.head.appendChild(link);
    }
    link.href = url;
    let meta = document.querySelector('meta[name="theme-color"]');
    if (!meta) {
      meta = document.createElement("meta");
      meta.setAttribute("name", "theme-color");
      document.head.appendChild(meta);
    }
    meta.setAttribute("content", "#0f2c5c");
    return () => URL.revokeObjectURL(url);
  }, []);

  const activeTimbratura = useMemo(() => {
    if (!currentUser) return null;
    return timbrature.find((t) => t.volontarioId === currentUser.id && !t.timestampOut) || null;
  }, [timbrature, currentUser]);

  const getLocation = (): Promise<GeolocationPosition> =>
    new Promise((res, rej) => {
      if (!navigator.geolocation) return rej(new Error("Geolocalizzazione non supportata"));
      navigator.geolocation.getCurrentPosition(res, rej, { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 });
    });

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2800);
  };

  const handleLogin = () => {
    const v = volontari.find((x) => x.id === loginId);
    if (!v) return setLoginError("Seleziona un volontario");
    if (v.pin !== pinInput) return setLoginError("PIN errato");
    setCurrentUser(v);
    setTab("home");
    setLoginError("");
    setPinInput("");
    showToast(`Benvenuto ${v.nome} ${v.cognome}`);
  };

  const handleTimbraNormale = async () => {
    if (!currentUser) return;
    if (activeTimbratura) return showToast("Hai già un servizio aperto");
    setGeoStatus("locating");
    try {
      const pos = await getLocation();
      const lat = pos.coords.latitude;
      const lon = pos.coords.longitude;
      const dist = haversine(lat, lon, SEDE.lat, SEDE.lon);
      setLastPos({ lat, lon, dist });
      if (dist > RAGGIO_METRI) {
        setGeoStatus("error");
        showToast(`Fuori sede: ${Math.round(dist)}m > ${RAGGIO_METRI}m`);
        return;
      }
      setGeoStatus("ok");
      const newT: Timbratura = {
        id: `t_${Date.now()}`,
        volontarioId: currentUser.id,
        tipo: "normale",
        timestampIn: new Date().toISOString(),
        latIn: lat,
        lonIn: lon,
        distanza: dist,
        validata: false,
        posizioniEmergenza: [],
      };
      const idKey = `timbratura-${newT.id}`;
      try { await records.create("pc_timbrature", newT, idKey); } catch {}
      setTimbrature((p) => [newT, ...p]);
      showToast("Timbratura normale registrata");
    } catch (e: any) {
      setGeoStatus("error");
      showToast(e.message || "Posizione non disponibile");
    }
  };

  const handleTimbraEmergenza = async () => {
    if (!currentUser) return;
    if (activeTimbratura && activeTimbratura.tipo === "normale") {
      showToast("Chiudi prima il servizio normale");
      return;
    }
    if (activeTimbratura?.tipo === "emergenza") {
      showToast("Emergenza già attiva");
      return;
    }
    setGeoStatus("locating");
    try {
      const pos = await getLocation();
      const newT: Timbratura = {
        id: `t_em_${Date.now()}`,
        volontarioId: currentUser.id,
        tipo: "emergenza",
        timestampIn: new Date().toISOString(),
        latIn: pos.coords.latitude,
        lonIn: pos.coords.longitude,
        distanza: 0,
        validata: true,
        posizioniEmergenza: [{ lat: pos.coords.latitude, lon: pos.coords.longitude, timestamp: new Date().toISOString() }],
      };
      try { await records.create("pc_timbrature", newT, `em-${newT.id}`); } catch {}
      setTimbrature((p) => [newT, ...p]);
      setEmergencyActiveId(newT.id);
      startEmergencyTracking(newT.id);
      if ("vibrate" in navigator) navigator.vibrate([200, 100, 200, 100, 400]);
      setGeoStatus("ok");
      showToast("EMERGENZA ATTIVATA - invio posizione ogni 30 sec (demo)");
    } catch (e: any) {
      setGeoStatus("error");
      showToast(e.message || "Posizione non disponibile");
    }
  };

  const startEmergencyTracking = (timbraturaId: string) => {
    setEmergencyCountdown(30);
    if (emergencyCountRef.current) window.clearInterval(emergencyCountRef.current);
    if (emergencyTimerRef.current) window.clearInterval(emergencyTimerRef.current);
    emergencyCountRef.current = window.setInterval(() => {
      setEmergencyCountdown((s) => (s <= 1 ? 30 : s - 1));
    }, 1000);
    emergencyTimerRef.current = window.setInterval(async () => {
      try {
        const pos = await getLocation();
        const point = { lat: pos.coords.latitude, lon: pos.coords.longitude, timestamp: new Date().toISOString() };
        setTimbrature((prev) =>
          prev.map((t) => (t.id === timbraturaId ? { ...t, posizioniEmergenza: [...(t.posizioniEmergenza || []), point] } : t))
        );
        const cur = timbrature.find((t) => t.id === timbraturaId);
        if (cur) {
          const updated = { ...cur, posizioniEmergenza: [...(cur.posizioniEmergenza || []), point] };
          try {
            const list = await records.list("pc_timbrature", 100);
            const rec = list.records.find((r: any) => r.value.id === timbraturaId);
            if (rec) await records.replace("pc_timbrature", rec.id, updated);
          } catch {}
        }
        showToast(`Posizione emergenza inviata: ${point.lat.toFixed(5)}`);
        setEmergencyCountdown(30);
      } catch {}
    }, 30000);
  };

  const stopEmergencyTracking = () => {
    if (emergencyTimerRef.current) window.clearInterval(emergencyTimerRef.current);
    if (emergencyCountRef.current) window.clearInterval(emergencyCountRef.current);
    setEmergencyActiveId(null);
    setEmergencyCountdown(30);
  };

  useEffect(() => {
    if (activeTimbratura?.tipo === "emergenza" && !emergencyActiveId) {
      setEmergencyActiveId(activeTimbratura.id);
      startEmergencyTracking(activeTimbratura.id);
    }
  }, [activeTimbratura, emergencyActiveId]);

  const handleFineServizio = async () => {
    if (!currentUser || !activeTimbratura) return;
    if (!resoconto.trim()) return showToast("Resoconto obbligatorio");
    setGeoStatus("locating");
    try {
      const pos = await getLocation().catch(() => null);
      const updated: Timbratura = {
        ...activeTimbratura,
        timestampOut: new Date().toISOString(),
        latOut: pos?.coords.latitude,
        lonOut: pos?.coords.longitude,
        resoconto: resoconto.trim(),
      };
      try {
        const list = await records.list("pc_timbrature", 100);
        const rec = list.records.find((r: any) => r.value.id === activeTimbratura.id);
        if (rec) await records.replace("pc_timbrature", rec.id, updated);
        else await records.create("pc_timbrature", updated, `close-${updated.id}`);
      } catch {}
      setTimbrature((p) => p.map((t) => (t.id === activeTimbratura.id ? updated : t)));
      setResoconto("");
      if (updated.tipo === "emergenza") stopEmergencyTracking();
      setGeoStatus("ok");
      showToast("Servizio chiuso");
    } catch (e: any) {
      showToast(e.message);
    }
  };

  const handleAddFerie = async () => {
    if (!currentUser) return;
    if (!ferieForm.inizio || !ferieForm.fine) return showToast("Date obbligatorie");
    const nf: Ferie = { id: `ferie_${Date.now()}`, volontarioId: currentUser.id, inizio: ferieForm.inizio, fine: ferieForm.fine, motivo: ferieForm.motivo, stato: "in_attesa" };
    try { await records.create("pc_ferie", nf, `ferie-${nf.id}`); } catch {}
    setFerie((p) => [nf, ...p]);
    setFerieForm({ inizio: "", fine: "", motivo: "" });
    showToast("Richiesta ferie inviata");
  };

  const handleAddRep = async () => {
    if (!currentUser) return;
    if (!repForm.data) return showToast("Data obbligatoria");
    const nr: Reperibilita = { id: `rep_${Date.now()}`, volontarioId: currentUser.id, data: repForm.data, dalle: repForm.dalle, alle: repForm.alle, note: repForm.note };
    try { await records.create("pc_reperibilita", nr, `rep-${nr.id}`); } catch {}
    setReperibilita((p) => [nr, ...p]);
    setRepForm({ data: "", dalle: "08:00", alle: "20:00", note: "" });
    showToast("Reperibilità salvata");
  };

  const handleSendChat = async () => {
    if (!currentUser || !chatTesto.trim()) return;
    const msg: ChatMsg = { id: `chat_${Date.now()}`, canale: chatCanale, volontarioId: currentUser.id, nome: `${currentUser.nome} ${currentUser.cognome}`, testo: chatTesto.trim(), timestamp: new Date().toISOString() };
    try { await records.create("pc_chat", msg, `chat-${msg.id}`); } catch {}
    setChat((p) => [...p, msg]);
    setChatTesto("");
  };

  const handleSaveVolontario = async () => {
    const isEdit = !!volForm.id;
    if (!volForm.nome || !volForm.cognome) return showToast("Nome e cognome obbligatori");
    const v: Volontario = {
      id: volForm.id || `v_${Date.now()}`,
      nome: volForm.nome!.trim(),
      cognome: volForm.cognome!.trim(),
      cf: (volForm.cf || "").toUpperCase(),
      telefono: volForm.telefono || "",
      email: volForm.email || "",
      qualifica: volForm.qualifica || "Volontario Operativo",
      stato: (volForm.stato as any) || "attivo",
      pin: volForm.pin || genPin(),
      ruolo: (volForm.ruolo as Ruolo) || "volontario",
    };
    try {
      if (isEdit) {
        const list = await records.list("pc_volontari", 100);
        const rec = list.records.find((r: any) => r.value.id === v.id);
        if (rec) await records.replace("pc_volontari", rec.id, v);
        else await records.create("pc_volontari", v, `vol-${v.id}`);
      } else {
        await records.create("pc_volontari", v, `vol-${v.id}`);
      }
    } catch (e: any) {
      if (e.message?.includes("limit")) return showToast("Limite storage raggiunto");
    }
    setVolontari((p) => {
      const exists = p.find((x) => x.id === v.id);
      if (exists) return p.map((x) => (x.id === v.id ? v : x));
      return [...p, v];
    });
    setShowVolModal(false);
    setVolForm({});
    showToast(isEdit ? "Volontario aggiornato" : "Volontario creato");
  };

  const handleDeleteVol = async (id: string) => {
    if (!confirm("Eliminare definitivamente questo volontario?")) return;
    try {
      const list = await records.list("pc_volontari", 100);
      const rec = list.records.find((r: any) => r.value.id === id);
      if (rec) await records.delete("pc_volontari", rec.id);
    } catch {}
    setVolontari((p) => p.filter((x) => x.id !== id));
    showToast("Volontario eliminato");
  };

  const handleApproveFerie = async (f: Ferie, nuovoStato: Ferie["stato"]) => {
    const upd = { ...f, stato: nuovoStato };
    try {
      const list = await records.list("pc_ferie", 100);
      const rec = list.records.find((r: any) => r.value.id === f.id);
      if (rec) await records.replace("pc_ferie", rec.id, upd);
    } catch {}
    setFerie((p) => p.map((x) => (x.id === f.id ? upd : x)));
    showToast(`Ferie ${nuovoStato}`);
  };

  const handleValidaTimbratura = async (t: Timbratura) => {
    const upd = { ...t, validata: true };
    try {
      const list = await records.list("pc_timbrature", 100);
      const rec = list.records.find((r: any) => r.value.id === t.id);
      if (rec) await records.replace("pc_timbrature", rec.id, upd);
    } catch {}
    setTimbrature((p) => p.map((x) => (x.id === t.id ? upd : x)));
    showToast("Timbratura avallata");
  };

  const handleSendAllerta = async () => {
    if (!currentUser) return;
    if (!allertaForm.titolo || !allertaForm.messaggio) return showToast("Titolo e messaggio obbligatori");
    const a: Allerta = { id: `all_${Date.now()}`, titolo: allertaForm.titolo, messaggio: allertaForm.messaggio, livello: allertaForm.livello, timestamp: new Date().toISOString(), mittenteId: currentUser.id };
    try {
      await records.create("pc_allerte", a, `all-${a.id}`);
      const msg: ChatMsg = { id: `chat_all_${Date.now()}`, canale: "Emergenze", volontarioId: currentUser.id, nome: `${currentUser.nome} ${currentUser.cognome}`, testo: `[${a.livello.toUpperCase()}] ${a.titolo}: ${a.messaggio}`, timestamp: a.timestamp };
      await records.create("pc_chat", msg, `chat-all-${a.id}`);
      setChat((p) => [...p, msg]);
    } catch {}
    setAllerte((p) => [a, ...p]);
    setAllertaForm({ titolo: "", messaggio: "", livello: "allerta" });
    showToast("Allertamento massivo inviato a tutti");
  };

  const filteredTimbratureForSchede = useMemo(() => {
    return timbrature.filter((t) => {
      const d = new Date(t.timestampIn);
      const matchMese = d.getMonth() === schedFilter.mese && d.getFullYear() === schedFilter.anno;
      const matchVol = schedFilter.volontarioId === "all" ? true : t.volontarioId === schedFilter.volontarioId;
      return matchMese && matchVol;
    });
  }, [timbrature, schedFilter]);

  const exportCSV = () => {
    const rows = filteredTimbratureForSchede;
    const header = ["Volontario", "Tipo", "Inizio", "Fine", "Ore", "Distanza m", "Resoconto", "Validata", "LatIn", "LonIn"];
    const lines = [header.join(";")].concat(
      rows.map((t) => {
        const vol = volontari.find((v) => v.id === t.volontarioId);
        const ore = diffHours(t.timestampIn, t.timestampOut).toFixed(2);
        return [vol ? `${vol.nome} ${vol.cognome}` : t.volontarioId, t.tipo, t.timestampIn, t.timestampOut || "", ore, String(Math.round(t.distanza || 0)), (t.resoconto || "").replace(/;/g, ","), t.validata ? "SI" : "NO", String(t.latIn), String(t.lonIn)].join(";");
      })
    );
    const blob = new Blob([lines.join("\n")], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `schede_${schedFilter.anno}_${schedFilter.mese + 1}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const tabsVol = [
    { id: "home", label: "Home", icon: "⌂" },
    { id: "timbra", label: "Timbra", icon: "◷" },
    { id: "ferie", label: "Ferie", icon: "▤" },
    { id: "chat", label: "Chat", icon: "✉" },
    { id: "schede", label: "Schede", icon: "≡" },
  ];
  const tabsCoord = [
    { id: "home", label: "Dashboard", icon: "◫" },
    { id: "volontari", label: "Volontari", icon: "◍" },
    { id: "allerta", label: "Allerta", icon: "⚑" },
    { id: "schede", label: "Schede", icon: "≡" },
    { id: "chat", label: "Chat", icon: "✉" },
  ];
  const tabs = isCoord ? tabsCoord : tabsVol;

  return (
    <div data-safe-area-inset-root className="min-h-screen bg-[var(--bg)] overflow-x-clip" style={{ boxSizing: "border-box", paddingTop: "var(--safe-area-inset-top)" }}>
      {loading ? (
        <div className="min-h-screen flex items-center justify-center">
          <div className="flex flex-col items-center gap-4">
            <img src={logoUrl} alt="Protezione Civile Logo" className="w-24 h-24 rounded-full shadow-xl animate-pulse" />
            <div className="h-2 w-32 bg-[var(--surface-2)] rounded-full overflow-hidden"><div className="h-full w-1/2 bg-[var(--primary)] animate-[slide_1s_infinite]"></div></div>
          </div>
        </div>
      ) : !currentUser ? (
        <div className="min-h-screen flex flex-col">
          <div className="flex-1 flex flex-col items-center px-5 py-8 max-w-[520px] mx-auto w-full">
            <div className="w-full bg-[var(--surface)] rounded-[28px] shadow-[var(--shadow)] border border-[var(--border)] p-7 mt-6">
              <div className="flex flex-col items-center text-center">
                <div className="relative">
                  <img src={logoUrl} alt="Protezione Civile Città di Alessandria - logo ufficiale blu arancio" className="w-[132px] h-[132px] rounded-full object-cover shadow-[0_8px_32px_rgba(15,44,92,0.25)] border-[4px] border-white" />
                  <div className="absolute -bottom-2 -right-2 bg-[var(--accent)] text-[var(--primary)] text-[10px] font-extrabold px-2.5 py-1 rounded-full border border-white shadow">AL</div>
                </div>
                <h1 className="mt-5 text-[22px] font-extrabold leading-[1.1] text-[var(--primary)]">Protezione Civile<br />Città di Alessandria</h1>
                <p className="mt-2 text-[13px] font-semibold tracking-wide text-[var(--orange)] uppercase">Ovunque, per tutti - Presenti quando conta.</p>
                <div className="mt-3 h-[3px] w-20 rounded-full bg-gradient-to-r from-[var(--primary)] via-[var(--accent)] to-[var(--orange)]"></div>
              </div>

              <div className="mt-8 space-y-5">
                <div>
                  <label className="text-[11px] font-bold tracking-[0.12em] text-[var(--text-soft)] uppercase">Volontario / Ruolo</label>
                  <div className="mt-2 relative">
                    <select value={loginId} onChange={(e) => setLoginId(e.target.value)} className="w-full h-[56px] rounded-[14px] bg-[var(--surface-2)] border border-[var(--border)] px-4 pr-10 text-[15px] font-semibold outline-none focus:border-[var(--primary)] focus:ring-2 focus:ring-[var(--primary)]/20">
                      {volontari.map((v) => (
                        <option key={v.id} value={v.id}>{v.nome} {v.cognome} — {v.ruolo === "coordinatore" ? "Coordinatore" : v.ruolo === "servizio" ? "Servizio Comunale" : v.qualifica}</option>
                      ))}
                    </select>
                    <span className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-[var(--text-soft)]">▼</span>
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-bold tracking-[0.12em] text-[var(--text-soft)] uppercase flex justify-between">
                    <span>PIN Sicurezza</span>
                    <button onClick={() => setShowPin((s) => !s)} className="text-[var(--primary)] underline"> {showPin ? "nascondi" : "mostra"} </button>
                  </label>
                  <div className="mt-2 relative">
                    <input
                      type={showPin ? "text" : "password"}
                      inputMode="numeric"
                      pattern="[0-9]*"
                      value={pinInput}
                      onChange={(e) => setPinInput(e.target.value.replace(/\D/g, "").slice(0, 6))}
                      placeholder="••••"
                      className="w-full h-[56px] rounded-[14px] bg-[var(--surface-2)] border border-[var(--border)] px-4 text-[22px] tracking-[0.4em] font-bold outline-none focus:border-[var(--primary)] focus:ring-2 focus:ring-[var(--primary)]/20"
                    />
                  </div>
                  <div className="mt-2 grid grid-cols-3 gap-2">
                    {[1,2,3,4,5,6,7,8,9].map(n=>(
                      <button key={n} onClick={()=> setPinInput(p=> (p+String(n)).slice(0,6))} className="h-[48px] rounded-[12px] bg-white border border-[var(--border)] font-bold text-[18px] active:scale-[0.98]"> {n} </button>
                    ))}
                    <button onClick={()=> setPinInput("")} className="h-[48px] rounded-[12px] bg-[var(--surface-2)] border border-[var(--border)] font-bold">C</button>
                    <button onClick={()=> setPinInput(p=> (p+"0").slice(0,6))} className="h-[48px] rounded-[12px] bg-white border border-[var(--border)] font-bold text-[18px] active:scale-[0.98]">0</button>
                    <button onClick={()=> setPinInput(p=> p.slice(0,-1))} className="h-[48px] rounded-[12px] bg-[var(--surface-2)] border border-[var(--border)]">⌫</button>
                  </div>
                </div>

                {loginError && <div className="rounded-[12px] bg-red-50 border border-red-200 text-red-700 px-4 py-3 text-[13px] font-semibold">{loginError}</div>}

                <button onClick={handleLogin} className="w-full h-[56px] rounded-[14px] bg-[var(--primary)] text-white font-extrabold text-[15px] tracking-wide shadow-[0_8px_20px_rgba(15,44,92,0.3)] active:scale-[0.99] transition">ACCEDI AL SERVIZIO</button>

                <div className="rounded-[14px] bg-[var(--surface-2)] border border-dashed border-[var(--border)] p-3 text-[11px] leading-[1.4] text-[var(--text-soft)]">
                  <b className="text-[var(--primary)]">Sede operativa:</b> {SEDE.indirizzo}<br />
                  Coordinate {SEDE.lat.toFixed(6)}, {SEDE.lon.toFixed(6)} • Raggio timbratura {RAGGIO_METRI}m • PIN demo: 1234 / 9999 / 0000
                  {apiError && <><br /><span className="text-amber-700 font-semibold">Modalità offline: {apiError}</span></>}
                </div>
              </div>
            </div>
            <div className="mt-6 flex items-center gap-2 text-[11px] text-[var(--text-soft)]">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span> Sistema operativo - Pronto per GitHub Pages
            </div>
          </div>
        </div>
      ) : (
        <>
          <header data-safe-area-sticky-top className="sticky z-30 backdrop-blur-xl bg-[var(--surface)]/90 border-b border-[var(--border)]" style={{ top: "var(--safe-area-inset-top)" }}>
            <div className="max-w-[980px] mx-auto px-4 h-[64px] flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img src={logoUrl} alt="Logo Protezione Civile Alessandria" className="w-10 h-10 rounded-full object-cover border border-[var(--border)] shadow-sm" />
                <div className="leading-[1.05]">
                  <div className="font-extrabold text-[13px] tracking-tight text-[var(--primary)]">PROTEZIONE CIVILE</div>
                  <div className="text-[11px] font-semibold text-[var(--text-soft)] -mt-0.5">Alessandria • {currentUser.nome} {currentUser.cognome}</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold border ${currentUser.stato === "attivo" ? "bg-emerald-50 text-emerald-700 border-emerald-200" : "bg-amber-50 text-amber-700 border-amber-200"}`}>{currentUser.ruolo.toUpperCase()}</div>
                <button onClick={() => setCurrentUser(null)} className="h-[36px] px-3 rounded-full bg-[var(--surface-2)] border border-[var(--border)] text-[12px] font-bold">Esci</button>
              </div>
            </div>
            {allerte[0] && (
              <div className="bg-gradient-to-r from-[var(--primary)] to-[#1a4a9a] text-white px-4 py-2 text-[12px] font-semibold flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[var(--accent)] animate-pulse"></span> ULTIMA ALLERTA: {allerte[0].titolo} — {allerte[0].messaggio.slice(0, 80)}
              </div>
            )}
          </header>

          <main className="max-w-[980px] mx-auto px-4 pb-[96px] pt-4">
            {tab === "home" && (
              <div className="space-y-4">
                <div className="rounded-[22px] bg-[var(--surface)] border border-[var(--border)] shadow-[var(--shadow)] p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h2 className="text-[20px] font-extrabold text-[var(--primary)] leading-tight">Ovunque, per tutti<br /><span className="text-[var(--orange)]">Presenti quando conta.</span></h2>
                      <p className="mt-2 text-[13px] text-[var(--text-soft)] leading-[1.5]">Sede: {SEDE.indirizzo}. Timbratura consentita entro {RAGGIO_METRI}m con verifica GPS Haversine.</p>
                    </div>
                    <img src={logoUrl} alt="Logo PC" className="w-14 h-14 rounded-full border border-[var(--border)] object-cover hidden sm:block" />
                  </div>
                  <div className="mt-4 grid grid-cols-3 gap-2">
                    <div className="rounded-[14px] bg-[var(--surface-2)] border border-[var(--border)] p-3">
                      <div className="text-[11px] font-bold text-[var(--text-soft)] uppercase tracking-wide">In servizio</div>
                      <div className="text-[20px] font-extrabold mt-1">{timbrature.filter(t=>!t.timestampOut).length}</div>
                    </div>
                    <div className="rounded-[14px] bg-[var(--surface-2)] border border-[var(--border)] p-3">
                      <div className="text-[11px] font-bold text-[var(--text-soft)] uppercase tracking-wide">Volontari attivi</div>
                      <div className="text-[20px] font-extrabold mt-1">{volontari.filter(v=>v.stato==="attivo").length}</div>
                    </div>
                    <div className="rounded-[14px] bg-[var(--primary)] text-white p-3">
                      <div className="text-[11px] font-bold opacity-80 uppercase tracking-wide">Ore mese</div>
                      <div className="text-[20px] font-extrabold mt-1">{filteredTimbratureForSchede.reduce((a,b)=>a+diffHours(b.timestampIn,b.timestampOut),0).toFixed(1)}h</div>
                    </div>
                  </div>
                </div>

                {activeTimbratura ? (
                  <div className={`rounded-[20px] border p-4 ${activeTimbratura.tipo==="emergenza" ? "bg-red-50 border-red-200" : "bg-emerald-50 border-emerald-200"}`}>
                    <div className="flex items-center justify-between">
                      <div className="font-extrabold text-[13px] uppercase tracking-wide">{activeTimbratura.tipo==="emergenza" ? "🚨 Emergenza attiva" : "● Servizio in corso"}</div>
                      <div className="text-[11px] font-semibold">{fmtDate(activeTimbratura.timestampIn)}</div>
                    </div>
                    {activeTimbratura.tipo==="emergenza" && emergencyActiveId && (
                      <div className="mt-3 rounded-[12px] bg-white border border-red-200 p-3 flex items-center justify-between">
                        <div className="text-[12px] font-bold">Invio posizione tra <span className="text-[var(--red)]">{emergencyCountdown}s</span></div>
                        <div className="text-[11px]">{activeTimbratura.posizioniEmergenza?.length || 0} punti salvati</div>
                      </div>
                    )}
                    <div className="mt-3">
                      <label className="text-[11px] font-bold uppercase text-[var(--text-soft)]">Resoconto per chiusura (obbligatorio)</label>
                      <textarea value={resoconto} onChange={e=>setResoconto(e.target.value)} placeholder="Descrivi attività svolta, mezzi, criticità..." className="mt-1 w-full min-h-[88px] rounded-[12px] border border-[var(--border)] bg-white p-3 text-[13px] outline-none focus:border-[var(--primary)]"></textarea>
                      <button onClick={handleFineServizio} className="mt-3 w-full h-[56px] rounded-[14px] bg-[var(--primary)] text-white font-extrabold active:scale-[0.99]">CHIUDI SERVIZIO</button>
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <button onClick={()=>setTab("timbra")} className="h-[72px] rounded-[18px] bg-[var(--surface)] border border-[var(--border)] shadow-sm flex items-center gap-3 px-5 active:scale-[0.99]">
                      <span className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 grid place-items-center font-extrabold text-[18px]">◷</span>
                      <span className="text-left"><span className="block font-extrabold text-[14px]">Timbra ingresso</span><span className="block text-[11px] text-[var(--text-soft)]">Verifica GPS entro 150m dalla sede</span></span>
                    </button>
                    <button onClick={handleTimbraEmergenza} className="h-[72px] rounded-[18px] bg-[var(--red)] text-white shadow-[0_8px_20px_rgba(225,29,45,0.35)] flex items-center gap-3 px-5 active:scale-[0.99]">
                      <span className="w-12 h-12 rounded-full bg-white/20 grid place-items-center font-extrabold">!</span>
                      <span className="text-left"><span className="block font-extrabold text-[14px]">EMERGENZA</span><span className="block text-[11px] opacity-90">Sempre attiva, invio pos. automatico</span></span>
                    </button>
                  </div>
                )}

                <div className="rounded-[18px] bg-[var(--surface)] border border-[var(--border)] p-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-extrabold text-[14px]">Ultime timbrature</h3>
                    <button onClick={()=>setTab("schede")} className="text-[12px] font-bold text-[var(--primary)]">Vedi tutte</button>
                  </div>
                  <div className="mt-3 space-y-2">
                    {timbrature.slice(0,5).map(t=>{
                      const vol = volontari.find(v=>v.id===t.volontarioId);
                      return (
                        <div key={t.id} className="flex items-center justify-between rounded-[12px] bg-[var(--surface-2)] border border-[var(--border)] px-3 py-2.5">
                          <div>
                            <div className="font-bold text-[12px]">{vol ? `${vol.nome} ${vol.cognome}` : t.volontarioId} • <span className={`px-1.5 py-0.5 rounded text-[10px] ${t.tipo==="emergenza" ? "bg-red-100 text-red-700" : "bg-emerald-100 text-emerald-700"}`}>{t.tipo.toUpperCase()}</span></div>
                            <div className="text-[11px] text-[var(--text-soft)]">{fmtDate(t.timestampIn)} {t.timestampOut ? `→ ${fmtDate(t.timestampOut)} (${diffHours(t.timestampIn,t.timestampOut).toFixed(1)}h)` : "• in corso"} {t.distanza ? `• ${Math.round(t.distanza)}m` : ""}</div>
                          </div>
                          {isCoord && !t.validata && <button onClick={()=>handleValidaTimbratura(t)} className="h-[32px] px-3 rounded-full bg-[var(--primary)] text-white text-[11px] font-bold">Avalla</button>}
                        </div>
                      );
                    })}
                    {timbrature.length===0 && <div className="text-[12px] text-[var(--text-soft)] py-6 text-center">Nessuna timbratura registrata</div>}
                  </div>
                </div>

                <div className="rounded-[18px] bg-[var(--surface)] border border-[var(--border)] p-4">
                  <h3 className="font-extrabold text-[13px]">Mappa sede operativa</h3>
                  <div className="mt-3 rounded-[14px] overflow-hidden border border-[var(--border)] bg-[var(--surface-2)] h-[180px] relative grid place-items-center">
                    <div className="absolute inset-0 opacity-30" style={{backgroundImage:"radial-gradient(circle at 50% 50%, var(--primary) 1px, transparent 1.5px)", backgroundSize:"18px 18px"}}></div>
                    <div className="relative z-10 text-center">
                      <div className="mx-auto w-10 h-10 rounded-full bg-[var(--primary)] text-white grid place-items-center font-extrabold shadow">📍</div>
                      <div className="mt-2 text-[12px] font-bold">{SEDE.indirizzo}</div>
                      <div className="text-[11px] text-[var(--text-soft)]">{SEDE.lat}, {SEDE.lon} • Raggio {RAGGIO_METRI}m</div>
                      {lastPos && <div className="mt-2 text-[11px] font-semibold text-emerald-700">Ultima posizione: {lastPos.dist.toFixed(0)}m — {lastPos.lat.toFixed(5)}, {lastPos.lon.toFixed(5)}</div>}
                      <div className="mt-2 inline-flex items-center gap-1 text-[10px] px-2 py-1 rounded-full bg-[var(--accent)] text-[var(--primary)] font-extrabold">VERIFICA HAVERSINE ATTIVA</div>
                    </div>
                  </div>
                  <div className="mt-2 text-[11px] text-[var(--text-soft)]">Formula: a=sin²(Δφ/2)+cos φ1·cos φ2·sin²(Δλ/2) • c=2·atan2(√a,√(1−a)) • d=R·c</div>
                </div>
              </div>
            )}

            {tab==="timbra" && (
              <div className="space-y-4">
                <div className="rounded-[20px] bg-[var(--surface)] border border-[var(--border)] p-5">
                  <h2 className="font-extrabold text-[18px] text-[var(--primary)]">Timbratura servizio</h2>
                  <p className="text-[12px] text-[var(--text-soft)] mt-1">Geolocalizzata, calcolo distanza dalla sede con Haversine. Emergenza sempre disponibile.</p>

                  {!activeTimbratura ? (
                    <div className="mt-5 space-y-4">
                      <button onClick={handleTimbraNormale} className="w-full h-[64px] rounded-[16px] bg-[var(--green)] hover:bg-[var(--green-2)] text-white font-extrabold text-[16px] tracking-wide shadow-[0_10px_24px_rgba(10,166,90,0.35)] active:scale-[0.99] flex items-center justify-center gap-3">
                        <span className="text-[22px]">◷</span> TIMBRA ENTRATA NORMALE
                      </button>
                      <div className="flex items-center gap-2"><div className="h-px flex-1 bg-[var(--border)]"></div><span className="text-[11px] font-bold text-[var(--text-soft)]">OPPURE</span><div className="h-px flex-1 bg-[var(--border)]"></div></div>
                      <button onClick={handleTimbraEmergenza} className="w-full h-[64px] rounded-[16px] bg-[var(--red)] hover:bg-[var(--red-2)] text-white font-extrabold text-[16px] tracking-wide shadow-[0_10px_24px_rgba(225,29,45,0.35)] active:scale-[0.99] flex items-center justify-center gap-3">
                        <span className="w-8 h-8 rounded-full bg-white text-[var(--red)] grid place-items-center font-black">!</span> TIMBRA EMERGENZA
                      </button>

                      <div className="rounded-[14px] bg-[var(--surface-2)] border border-[var(--border)] p-3">
                        <div className="flex items-center justify-between">
                          <span className="text-[11px] font-bold uppercase text-[var(--text-soft)]">Stato GPS</span>
                          <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${geoStatus==="ok" ? "bg-emerald-100 text-emerald-700" : geoStatus==="locating" ? "bg-amber-100 text-amber-700" : geoStatus==="error" ? "bg-red-100 text-red-700" : "bg-[var(--surface)] border"}`}>{geoStatus.toUpperCase()}</span>
                        </div>
                        {lastPos ? (
                          <div className="mt-2 text-[12px]"><b>Distanza:</b> {lastPos.dist.toFixed(1)}m {lastPos.dist<=RAGGIO_METRI ? "✅ entro sede" : "❌ fuori sede"}<br /><b>Coords:</b> {lastPos.lat.toFixed(6)}, {lastPos.lon.toFixed(6)}</div>
                        ) : <div className="mt-2 text-[12px] text-[var(--text-soft)]">Nessuna posizione acquisita. Consenti GPS per timbrare.</div>}
                      </div>

                      <div className="rounded-[14px] overflow-hidden border border-[var(--border)] bg-[var(--surface-2)] h-[160px] grid place-items-center relative">
                        <div className="text-center">
                          <div className="text-[12px] font-bold">Sede: {SEDE.indirizzo}</div>
                          <div className="text-[11px] text-[var(--text-soft)]">Raggio {RAGGIO_METRI}m • {SEDE.lat}, {SEDE.lon}</div>
                          <div className="mt-2 w-16 h-16 mx-auto rounded-full border-4 border-[var(--primary)]/20 grid place-items-center"><div className="w-3 h-3 rounded-full bg-[var(--primary)]"></div></div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="mt-4">
                      <div className={`rounded-[16px] border p-4 ${activeTimbratura.tipo==="emergenza" ? "bg-red-50 border-red-200" : "bg-emerald-50 border-emerald-200"}`}>
                        <div className="font-extrabold">{activeTimbratura.tipo==="emergenza" ? "🚨 EMERGENZA IN CORSO" : "Servizio in corso"}</div>
                        <div className="text-[12px] mt-1">Inizio: {fmtDate(activeTimbratura.timestampIn)}<br />Lat/Lon in: {activeTimbratura.latIn.toFixed(5)}, {activeTimbratura.lonIn.toFixed(5)}</div>
                        {activeTimbratura.tipo==="emergenza" && (
                          <div className="mt-3 rounded-[12px] bg-white border p-3">
                            <div className="text-[11px] font-bold uppercase">Tracking emergenza (demo 30s)</div>
                            <div className="mt-2 flex items-center gap-3">
                              <div className="flex-1 h-2 bg-[var(--surface-2)] rounded-full overflow-hidden"><div className="h-full bg-[var(--red)] transition-all" style={{width:`${((30-emergencyCountdown)/30)*100}%`}}></div></div>
                              <span className="text-[12px] font-bold">{emergencyCountdown}s</span>
                            </div>
                            <div className="mt-2 text-[11px]">{activeTimbratura.posizioniEmergenza?.length || 0} posizioni salvate</div>
                            <div className="mt-2 max-h-[120px] overflow-auto space-y-1">
                              {(activeTimbratura.posizioniEmergenza||[]).slice().reverse().map((p,i)=>(
                                <div key={i} className="text-[10px] bg-[var(--surface-2)] rounded px-2 py-1">{fmtDate(p.timestamp)} — {p.lat.toFixed(5)}, {p.lon.toFixed(5)}</div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                      <div className="mt-4">
                        <label className="text-[11px] font-bold uppercase">Resoconto obbligatorio fine servizio</label>
                        <textarea value={resoconto} onChange={e=>setResoconto(e.target.value)} className="mt-1 w-full min-h-[110px] rounded-[12px] border border-[var(--border)] p-3 text-[13px] outline-none focus:border-[var(--primary)]" placeholder="Cosa hai fatto, mezzi usati, criticità, esito..."></textarea>
                        <button onClick={handleFineServizio} className="mt-3 w-full h-[56px] rounded-[14px] bg-[var(--primary)] text-white font-extrabold">FINE SERVIZIO + INVIA RESOCONTO</button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {tab==="ferie" && (
              <div className="space-y-4">
                <div className="rounded-[20px] bg-[var(--surface)] border border-[var(--border)] p-5">
                  <h2 className="font-extrabold text-[18px] text-[var(--primary)]">Ferie e Reperibilità</h2>
                  <div className="mt-5">
                    <h3 className="font-bold text-[13px]">Richiesta ferie / permesso</h3>
                    <div className="mt-3 grid grid-cols-2 gap-3">
                      <div><label className="text-[11px] font-bold uppercase text-[var(--text-soft)]">Inizio</label><input type="date" value={ferieForm.inizio} onChange={e=>setFerieForm({...ferieForm,inizio:e.target.value})} className="mt-1 w-full h-[44px] rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3 text-[13px]" /></div>
                      <div><label className="text-[11px] font-bold uppercase text-[var(--text-soft)]">Fine</label><input type="date" value={ferieForm.fine} onChange={e=>setFerieForm({...ferieForm,fine:e.target.value})} className="mt-1 w-full h-[44px] rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3 text-[13px]" /></div>
                    </div>
                    <textarea value={ferieForm.motivo} onChange={e=>setFerieForm({...ferieForm,motivo:e.target.value})} placeholder="Motivo (ferie, famiglia, salute...)" className="mt-3 w-full min-h-[72px] rounded-[12px] border border-[var(--border)] p-3 text-[13px]"></textarea>
                    <button onClick={handleAddFerie} className="mt-3 w-full h-[48px] rounded-[12px] bg-[var(--primary)] text-white font-bold">Invia richiesta</button>
                  </div>
                  <div className="mt-6">
                    <h3 className="font-bold text-[13px]">Reperibilità</h3>
                    <div className="mt-3 grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div><label className="text-[11px] font-bold uppercase">Data</label><input type="date" value={repForm.data} onChange={e=>setRepForm({...repForm,data:e.target.value})} className="mt-1 w-full h-[44px] rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3 text-[13px]" /></div>
                      <div><label className="text-[11px] font-bold uppercase">Dalle</label><input type="time" value={repForm.dalle} onChange={e=>setRepForm({...repForm,dalle:e.target.value})} className="mt-1 w-full h-[44px] rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3 text-[13px]" /></div>
                      <div><label className="text-[11px] font-bold uppercase">Alle</label><input type="time" value={repForm.alle} onChange={e=>setRepForm({...repForm,alle:e.target.value})} className="mt-1 w-full h-[44px] rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3 text-[13px]" /></div>
                    </div>
                    <input value={repForm.note} onChange={e=>setRepForm({...repForm,note:e.target.value})} placeholder="Note (es. telefono secondario, zona)" className="mt-3 w-full h-[44px] rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3 text-[13px]" />
                    <button onClick={handleAddRep} className="mt-3 w-full h-[48px] rounded-[12px] bg-[var(--surface-2)] border border-[var(--border)] font-bold">Salva reperibilità</button>
                  </div>
                  <div className="mt-6 space-y-3">
                    <h3 className="font-bold text-[13px]">Le tue richieste</h3>
                    {ferie.filter(f=>f.volontarioId===currentUser.id).map(f=>(
                      <div key={f.id} className="rounded-[12px] bg-[var(--surface-2)] border border-[var(--border)] p-3 flex justify-between">
                        <div><div className="font-bold text-[12px]">{fmtOnlyDate(f.inizio)} → {fmtOnlyDate(f.fine)}</div><div className="text-[11px] text-[var(--text-soft)]">{f.motivo}</div></div>
                        <div className={`h-fit px-2 py-1 rounded-full text-[10px] font-bold border ${f.stato==="approvata" ? "bg-emerald-50 text-emerald-700 border-emerald-200" : f.stato==="rifiutata" ? "bg-red-50 text-red-700 border-red-200" : "bg-amber-50 text-amber-700 border-amber-200"}`}>{f.stato.toUpperCase()}</div>
                      </div>
                    ))}
                    {reperibilita.filter(r=>r.volontarioId===currentUser.id).map(r=>(
                      <div key={r.id} className="rounded-[12px] bg-white border border-[var(--border)] p-3 flex justify-between">
                        <div className="text-[12px]"><b>{fmtOnlyDate(r.data)}</b> {r.dalle}–{r.alle} {r.note ? `• ${r.note}` : ""}</div>
                      </div>
                    ))}
                    {isCoord && (
                      <>
                        <h3 className="font-bold text-[13px] mt-6">Da approvare (coordinatore)</h3>
                        {ferie.filter(f=>f.stato==="in_attesa").map(f=>{
                          const vol = volontari.find(v=>v.id===f.volontarioId);
                          return (
                            <div key={f.id} className="rounded-[12px] bg-amber-50 border border-amber-200 p-3">
                              <div className="font-bold text-[12px]">{vol ? `${vol.nome} ${vol.cognome}` : f.volontarioId} — {fmtOnlyDate(f.inizio)} → {fmtOnlyDate(f.fine)}</div>
                              <div className="text-[11px]">{f.motivo}</div>
                              <div className="mt-2 flex gap-2">
                                <button onClick={()=>handleApproveFerie(f,"approvata")} className="h-[36px] px-3 rounded-full bg-emerald-600 text-white text-[11px] font-bold">Approva</button>
                                <button onClick={()=>handleApproveFerie(f,"rifiutata")} className="h-[36px] px-3 rounded-full bg-red-600 text-white text-[11px] font-bold">Rifiuta</button>
                              </div>
                            </div>
                          );
                        })}
                      </>
                    )}
                  </div>
                </div>
              </div>
            )}

            {tab==="chat" && (
              <div className="space-y-3">
                <div className="rounded-[20px] bg-[var(--surface)] border border-[var(--border)] p-4">
                  <h2 className="font-extrabold text-[16px]">Chat interna</h2>
                  <div className="mt-3 flex gap-2">
                    {(["Generale","Emergenze","Coordinamento"] as const).map(c=>(
                      <button key={c} onClick={()=>setChatCanale(c)} className={`h-[40px] px-4 rounded-full border text-[12px] font-bold ${chatCanale===c ? "bg-[var(--primary)] text-white border-[var(--primary)]" : "bg-[var(--surface-2)] border-[var(--border)]"}`}>{c}</button>
                    ))}
                  </div>
                  <div className="mt-4 max-h-[420px] overflow-auto space-y-2 pr-1 scrollbar-none">
                    {chat.filter(m=>m.canale===chatCanale).map(m=>(
                      <div key={m.id} className={`rounded-[14px] p-3 border max-w-[85%] ${m.volontarioId===currentUser.id ? "ml-auto bg-[var(--primary)] text-white border-[var(--primary)]" : "bg-[var(--surface-2)] border-[var(--border)]"}`}>
                        <div className="flex justify-between gap-2"><span className="font-bold text-[11px]">{m.nome}</span><span className="text-[10px] opacity-70">{fmtDate(m.timestamp)}</span></div>
                        <div className="text-[13px] mt-1 leading-[1.4]">{m.testo}</div>
                      </div>
                    ))}
                    {chat.filter(m=>m.canale===chatCanale).length===0 && <div className="text-[12px] text-[var(--text-soft)] text-center py-8">Nessun messaggio in {chatCanale}</div>}
                  </div>
                  <div className="mt-3 flex gap-2">
                    <input value={chatTesto} onChange={e=>setChatTesto(e.target.value)} onKeyDown={e=> e.key==="Enter" && handleSendChat()} placeholder={`Messaggio in ${chatCanale}...`} className="flex-1 h-[48px] rounded-full border border-[var(--border)] bg-[var(--surface-2)] px-4 text-[13px] outline-none focus:border-[var(--primary)]" />
                    <button onClick={handleSendChat} className="h-[48px] w-[48px] rounded-full bg-[var(--primary)] text-white grid place-items-center font-bold active:scale-95">➤</button>
                  </div>
                </div>
              </div>
            )}

            {tab==="schede" && (
              <div className="space-y-4">
                <div className="rounded-[20px] bg-[var(--surface)] border border-[var(--border)] p-5">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <h2 className="font-extrabold text-[18px]">Schede volontari mese per mese</h2>
                    <button onClick={exportCSV} className="h-[40px] px-4 rounded-full bg-[var(--accent)] text-[var(--primary)] font-extrabold text-[12px] border border-black/10">Esporta CSV</button>
                  </div>
                  <div className="mt-4 grid grid-cols-3 gap-2">
                    <select value={schedFilter.mese} onChange={e=>setSchedFilter({...schedFilter,mese:Number(e.target.value)})} className="h-[44px] rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3 text-[13px] font-semibold">
                      {Array.from({length:12},(_,i)=> <option key={i} value={i}>{new Date(0,i).toLocaleString("it-IT",{month:"long"})}</option>)}
                    </select>
                    <select value={schedFilter.anno} onChange={e=>setSchedFilter({...schedFilter,anno:Number(e.target.value)})} className="h-[44px] rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3 text-[13px] font-semibold">
                      {[2024,2025,2026].map(y=> <option key={y} value={y}>{y}</option>)}
                    </select>
                    {isCoord && (
                      <select value={schedFilter.volontarioId} onChange={e=>setSchedFilter({...schedFilter,volontarioId:e.target.value})} className="h-[44px] rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3 text-[13px] font-semibold">
                        <option value="all">Tutti i volontari</option>
                        {volontari.map(v=> <option key={v.id} value={v.id}>{v.nome} {v.cognome}</option>)}
                      </select>
                    )}
                  </div>

                  <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {(isCoord && schedFilter.volontarioId==="all" ? volontari : volontari.filter(v=> isCoord ? true : v.id===currentUser.id).filter(v=> schedFilter.volontarioId==="all" ? true : v.id===schedFilter.volontarioId)).map(v=>{
                      const tList = filteredTimbratureForSchede.filter(t=>t.volontarioId===v.id);
                      const ore = tList.reduce((a,b)=>a+diffHours(b.timestampIn,b.timestampOut),0);
                      const ferieM = ferie.filter(f=>f.volontarioId===v.id && new Date(f.inizio).getMonth()===schedFilter.mese && new Date(f.inizio).getFullYear()===schedFilter.anno);
                      const repM = reperibilita.filter(r=>r.volontarioId===v.id && new Date(r.data).getMonth()===schedFilter.mese && new Date(r.data).getFullYear()===schedFilter.anno);
                      return (
                        <div key={v.id} className="rounded-[16px] border border-[var(--border)] bg-[var(--surface-2)] p-4">
                          <div className="flex justify-between items-start">
                            <div><div className="font-extrabold text-[13px]">{v.nome} {v.cognome}</div><div className="text-[11px] text-[var(--text-soft)]">{v.qualifica} • {v.stato}</div></div>
                            <div className="text-right"><div className="text-[18px] font-extrabold">{ore.toFixed(1)}h</div><div className="text-[10px] font-bold text-[var(--text-soft)]">{tList.length} servizi</div></div>
                          </div>
                          <div className="mt-3 space-y-1.5 max-h-[220px] overflow-auto pr-1">
                            {tList.slice(0,12).map(t=>(
                              <button key={t.id} onClick={()=>setSelectedDayDetail(t)} className="w-full text-left rounded-[10px] bg-white border border-[var(--border)] px-3 py-2 hover:border-[var(--primary)]">
                                <div className="flex justify-between"><span className="text-[11px] font-bold">{fmtDate(t.timestampIn).slice(0,6)} • {t.tipo.toUpperCase()}</span><span className="text-[10px]">{t.timestampOut ? `${diffHours(t.timestampIn,t.timestampOut).toFixed(1)}h` : "in corso"}</span></div>
                                <div className="text-[11px] text-[var(--text-soft)] truncate">{t.resoconto || "Senza resoconto"} {t.posizioniEmergenza?.length ? `• ${t.posizioniEmergenza.length} pos. emergenza` : ""}</div>
                              </button>
                            ))}
                            {tList.length===0 && <div className="text-[11px] text-[var(--text-soft)]">Nessun servizio nel mese</div>}
                          </div>
                          <div className="mt-3 flex gap-2 text-[10px]">
                            <span className="px-2 py-1 rounded-full bg-white border">Ferie: {ferieM.length}</span>
                            <span className="px-2 py-1 rounded-full bg-white border">Reperibilità: {repM.length}</span>
                            <span className="px-2 py-1 rounded-full bg-white border">Emergenze: {tList.filter(t=>t.tipo==="emergenza").length}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {tab==="volontari" && isCoord && (
              <div className="space-y-4">
                <div className="rounded-[20px] bg-[var(--surface)] border border-[var(--border)] p-5">
                  <div className="flex justify-between items-center">
                    <h2 className="font-extrabold text-[18px]">Gestione volontari</h2>
                    <button onClick={()=>{setVolForm({}); setShowVolModal(true);}} className="h-[44px] px-4 rounded-full bg-[var(--primary)] text-white font-bold text-[12px]">+ Nuovo volontario</button>
                  </div>
                  <div className="mt-4 space-y-3">
                    {volontari.map(v=>(
                      <div key={v.id} className="rounded-[16px] border border-[var(--border)] bg-[var(--surface-2)] p-4 flex justify-between gap-3">
                        <div className="min-w-0">
                          <div className="font-extrabold text-[13px] flex items-center gap-2">{v.nome} {v.cognome} <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold border ${v.ruolo==="coordinatore"||v.ruolo==="servizio" ? "bg-[var(--primary)] text-white border-[var(--primary)]" : "bg-white border-[var(--border)]"}`}>{v.ruolo}</span></div>
                          <div className="text-[11px] text-[var(--text-soft)] truncate">{v.cf} • {v.telefono} • {v.email}</div>
                          <div className="text-[11px] mt-1 flex items-center gap-2">
                            <span>PIN: {showVolPin[v.id] ? <b>{v.pin}</b> : "••••"}</span>
                            <button onClick={()=>setShowVolPin(s=>({...s,[v.id]:!s[v.id]}))} className="w-6 h-6 rounded-full bg-white border grid place-items-center text-[12px]">{showVolPin[v.id] ? "🙈" : "👁️"}</button>
                            <span className={`px-2 py-0.5 rounded-full text-[10px] border ${v.stato==="attivo" ? "bg-emerald-50 text-emerald-700 border-emerald-200" : "bg-amber-50 text-amber-700 border-amber-200"}`}>{v.stato}</span>
                          </div>
                        </div>
                        <div className="flex flex-col gap-2 shrink-0">
                          <button onClick={()=>{setVolForm(v); setShowVolModal(true);}} className="h-[36px] px-3 rounded-full bg-white border border-[var(--border)] text-[11px] font-bold">Modifica</button>
                          <button onClick={()=>handleDeleteVol(v.id)} className="h-[36px] px-3 rounded-full bg-red-50 border border-red-200 text-red-700 text-[11px] font-bold">Elimina</button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {tab==="allerta" && isCoord && (
              <div className="space-y-4">
                <div className="rounded-[20px] bg-[var(--surface)] border border-[var(--border)] p-5">
                  <h2 className="font-extrabold text-[18px]">Allertamento massivo</h2>
                  <p className="text-[12px] text-[var(--text-soft)] mt-1">Invia notifica a tutti i volontari, verrà registrata in chat Emergenze e in home.</p>
                  <div className="mt-4 space-y-3">
                    <input value={allertaForm.titolo} onChange={e=>setAllertaForm({...allertaForm,titolo:e.target.value})} placeholder="Titolo allerta (es. Allerta meteo arancione)" className="w-full h-[48px] rounded-[12px] border border-[var(--border)] bg-[var(--surface-2)] px-4 text-[13px]" />
                    <select value={allertaForm.livello} onChange={e=>setAllertaForm({...allertaForm,livello:e.target.value as any})} className="w-full h-[48px] rounded-[12px] border border-[var(--border)] bg-[var(--surface-2)] px-4 text-[13px] font-bold">
                      <option value="info">INFO</option><option value="allerta">ALLERTA</option><option value="emergenza">EMERGENZA</option>
                    </select>
                    <textarea value={allertaForm.messaggio} onChange={e=>setAllertaForm({...allertaForm,messaggio:e.target.value})} placeholder="Messaggio dettagliato, luogo ritrovo, orario, dotazioni..." className="w-full min-h-[120px] rounded-[12px] border border-[var(--border)] bg-[var(--surface-2)] p-4 text-[13px]"></textarea>
                    <button onClick={handleSendAllerta} className="w-full h-[56px] rounded-[14px] bg-[var(--orange)] text-[var(--primary)] font-extrabold shadow">INVIA A TUTTI I VOLONTARI</button>
                  </div>
                  <div className="mt-6 space-y-2">
                    <h3 className="font-bold text-[12px]">Storico allerte</h3>
                    {allerte.map(a=>(
                      <div key={a.id} className="rounded-[12px] border border-[var(--border)] bg-[var(--surface-2)] p-3">
                        <div className="flex justify-between"><span className="font-bold text-[12px]">[{a.livello.toUpperCase()}] {a.titolo}</span><span className="text-[10px] text-[var(--text-soft)]">{fmtDate(a.timestamp)}</span></div>
                        <div className="text-[11px] mt-1">{a.messaggio}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </main>

          <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[var(--surface)]/95 backdrop-blur-xl border-t border-[var(--border)]" style={{ paddingBottom: "calc(env(safe-area-inset-bottom) + 6px)" }}>
            <div className="max-w-[980px] mx-auto px-2 h-[72px] flex items-center justify-around">
              {tabs.map(t=>(
                <button key={t.id} onClick={()=>setTab(t.id)} className={`flex flex-col items-center justify-center gap-1 min-w-[56px] h-[56px] rounded-[14px] transition ${tab===t.id ? "bg-[var(--primary)] text-white shadow" : "text-[var(--text-soft)]"}`}>
                  <span className="text-[18px] leading-none">{t.icon}</span>
                  <span className="text-[10px] font-extrabold tracking-wide">{t.label}</span>
                </button>
              ))}
            </div>
          </nav>

          {showVolModal && (
            <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm p-4 flex items-end sm:items-center justify-center overflow-auto">
              <div className="w-full max-w-[560px] rounded-[22px] bg-[var(--surface)] border border-[var(--border)] shadow-2xl p-5 max-h-[90vh] overflow-auto">
                <div className="flex justify-between items-center">
                  <h3 className="font-extrabold text-[16px]">{volForm.id ? "Modifica volontario" : "Nuovo volontario"}</h3>
                  <button onClick={()=>setShowVolModal(false)} className="w-8 h-8 rounded-full bg-[var(--surface-2)] border grid place-items-center">✕</button>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-3">
                  <div><label className="text-[11px] font-bold uppercase">Nome</label><input value={volForm.nome||""} onChange={e=>setVolForm({...volForm,nome:e.target.value})} className="mt-1 w-full h-[44px] rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3 text-[13px]" /></div>
                  <div><label className="text-[11px] font-bold uppercase">Cognome</label><input value={volForm.cognome||""} onChange={e=>setVolForm({...volForm,cognome:e.target.value})} className="mt-1 w-full h-[44px] rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3 text-[13px]" /></div>
                  <div className="col-span-2"><label className="text-[11px] font-bold uppercase">CF</label><input value={volForm.cf||""} onChange={e=>setVolForm({...volForm,cf:e.target.value})} className="mt-1 w-full h-[44px] rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3 text-[13px]" /></div>
                  <div><label className="text-[11px] font-bold uppercase">Telefono</label><input value={volForm.telefono||""} onChange={e=>setVolForm({...volForm,telefono:e.target.value})} className="mt-1 w-full h-[44px] rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3 text-[13px]" /></div>
                  <div><label className="text-[11px] font-bold uppercase">Email</label><input value={volForm.email||""} onChange={e=>setVolForm({...volForm,email:e.target.value})} className="mt-1 w-full h-[44px] rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3 text-[13px]" /></div>
                  <div><label className="text-[11px] font-bold uppercase">Qualifica</label><input value={volForm.qualifica||""} onChange={e=>setVolForm({...volForm,qualifica:e.target.value})} className="mt-1 w-full h-[44px] rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3 text-[13px]" /></div>
                  <div><label className="text-[11px] font-bold uppercase">Stato</label><select value={volForm.stato||"attivo"} onChange={e=>setVolForm({...volForm,stato:e.target.value as any})} className="mt-1 w-full h-[44px] rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3 text-[13px]"><option value="attivo">attivo</option><option value="sospeso">sospeso</option></select></div>
                  <div><label className="text-[11px] font-bold uppercase">Ruolo</label><select value={volForm.ruolo||"volontario"} onChange={e=>setVolForm({...volForm,ruolo:e.target.value as any})} className="mt-1 w-full h-[44px] rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3 text-[13px]"><option value="volontario">volontario</option><option value="coordinatore">coordinatore</option><option value="servizio">servizio</option></select></div>
                  <div className="col-span-2">
                    <label className="text-[11px] font-bold uppercase flex justify-between"><span>PIN (visibile solo a coordinatore/servizio)</span><button onClick={()=>setVolForm({...volForm,pin:genPin()})} className="text-[var(--primary)] underline">Rigenera</button></label>
                    <div className="mt-1 flex gap-2"><input value={volForm.pin||""} onChange={e=>setVolForm({...volForm,pin:e.target.value})} className="flex-1 h-[44px] rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3 text-[14px] font-bold tracking-widest" /><span className="h-[44px] px-3 rounded-[10px] bg-[var(--surface-2)] border border-[var(--border)] grid place-items-center text-[12px] font-bold">{volForm.pin ? "👁️ visibile" : "nascosto"}</span></div>
                  </div>
                </div>
                <div className="mt-5 flex gap-3">
                  <button onClick={()=>setShowVolModal(false)} className="flex-1 h-[48px] rounded-[12px] bg-[var(--surface-2)] border border-[var(--border)] font-bold">Annulla</button>
                  <button onClick={handleSaveVolontario} className="flex-1 h-[48px] rounded-[12px] bg-[var(--primary)] text-white font-extrabold">Salva volontario</button>
                </div>
              </div>
            </div>
          )}

          {selectedDayDetail && (
            <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm p-4 flex items-end sm:items-center justify-center overflow-auto">
              <div className="w-full max-w-[560px] rounded-[22px] bg-[var(--surface)] border border-[var(--border)] shadow-2xl p-5">
                <div className="flex justify-between items-center">
                  <h3 className="font-extrabold text-[15px]">Dettaglio servizio</h3>
                  <button onClick={()=>setSelectedDayDetail(null)} className="w-8 h-8 rounded-full bg-[var(--surface-2)] border grid place-items-center">✕</button>
                </div>
                <div className="mt-4 space-y-3 text-[12px]">
                  <div><b>Volontario:</b> {volontari.find(v=>v.id===selectedDayDetail.volontarioId)?.nome} {volontari.find(v=>v.id===selectedDayDetail.volontarioId)?.cognome}</div>
                  <div><b>Tipo:</b> {selectedDayDetail.tipo.toUpperCase()} {selectedDayDetail.validata ? "✅ avallata" : "⏳ da avallare"}</div>
                  <div><b>Inizio:</b> {fmtDate(selectedDayDetail.timestampIn)} — lat {selectedDayDetail.latIn.toFixed(6)} lon {selectedDayDetail.lonIn.toFixed(6)} {selectedDayDetail.distanza ? `(${Math.round(selectedDayDetail.distanza)}m da sede)` : ""}</div>
                  {selectedDayDetail.timestampOut && <div><b>Fine:</b> {fmtDate(selectedDayDetail.timestampOut)} {selectedDayDetail.latOut ? `— ${selectedDayDetail.latOut.toFixed(5)}, ${selectedDayDetail.lonOut?.toFixed(5)}` : ""} — Ore: {diffHours(selectedDayDetail.timestampIn,selectedDayDetail.timestampOut).toFixed(2)}h</div>}
                  <div className="rounded-[12px] bg-[var(--surface-2)] border p-3"><b>Resoconto:</b><br />{selectedDayDetail.resoconto || "Nessun resoconto"}</div>
                  {selectedDayDetail.posizioniEmergenza && selectedDayDetail.posizioniEmergenza.length>0 && (
                    <div>
                      <b>Posizioni emergenza ({selectedDayDetail.posizioniEmergenza.length}):</b>
                      <div className="mt-2 max-h-[160px] overflow-auto space-y-1">
                        {selectedDayDetail.posizioniEmergenza.map((p,i)=><div key={i} className="rounded px-2 py-1 bg-[var(--surface-2)] border text-[11px]">{fmtDate(p.timestamp)} — {p.lat.toFixed(5)}, {p.lon.toFixed(5)}</div>)}
                      </div>
                    </div>
                  )}
                </div>
                <button onClick={()=>setSelectedDayDetail(null)} className="mt-5 w-full h-[48px] rounded-[12px] bg-[var(--primary)] text-white font-bold">Chiudi</button>
              </div>
            </div>
          )}

          {toast && <div className="fixed left-1/2 -translate-x-1/2 bottom-[88px] z-50 bg-[#0f1e3a] text-white px-4 py-3 rounded-full text-[12px] font-bold shadow-xl border border-white/10 max-w-[92%] text-center">{toast}</div>}
        </>
      )}

      <style>{`@keyframes slide{0%{transform:translateX(-100%)}100%{transform:translateX(200%)}}`}</style>
    </div>
  );
}
