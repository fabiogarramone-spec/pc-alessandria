import React, { useEffect, useState } from "react";
import officialLogoUrl from "container:///mnt/data/src/assets/739202fb338e864d-Protezione_Civile_Logo";

// ---- BACKEND HELPERS (required contract) ----
async function apiFetch(action: string, args: any) {
  // REQUIRED: direct literal fetch("actions", ...) with POST and json
  const res = await fetch("actions", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ action, args }),
  });
  const json = await res.json();
  if (!res.ok || json.error) throw new Error(json.error || "API error");
  return json.data;
}

type SavedPackage = { id: string; value: any };

function generateStandaloneHtml(logoDataUrl: string): string {
  const safeLogo = logoDataUrl.replace(/'/g, "");
  return `<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover,user-scalable=no,maximum-scale=1"/>
<title>Protezione Civile Alessandria - Ovunque, per tutti</title>
<meta name="theme-color" content="#0f2c5c"/>
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-title" content="PC Alessandria"/>
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"/>
<link id="manifest-link" rel="manifest" href=""/>
<link rel="apple-touch-icon" href="${safeLogo}"/>
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;900&display=swap');
:root{--pc-blue:#0f2c5c;--pc-yellow:#ffcc00;--bg:#f4f6fb;--surface:#fff;--surface-2:#eef2fb;--text:#0f2c5c;--text-2:#5a6d94;--border:#d8e0f0;--ok:#0a7a42;--danger:#d61f2d}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;padding:0;min-height:100%;background:var(--bg);color:var(--text);font-family:Inter,system-ui,-apple-system,sans-serif;overscroll-behavior:none}
button,a{cursor:pointer;touch-action:manipulation}
input,select,textarea{font-size:16px}
.login-wrap{min-height:100dvh;background:#0f2c5c;display:flex;align-items:center;justify-content:center;padding:20px;position:relative;overflow:hidden}
.login-bg{position:absolute;inset:0;background:radial-gradient(circle at 20% 10%,#1a4a9a 0%,#0f2c5c 55%)}
.login-content{position:relative;z-index:1;max-width:440px;width:100%;display:flex;flex-direction:column;gap:18px;align-items:center}
.login-logo{width:128px;height:128px;background:white;border-radius:28px;display:flex;align-items:center;justify-content:center;padding:12px;box-shadow:0 20px 60px rgba(0,0,0,0.35)}
.login-logo img{width:100%;height:100%;object-fit:contain}
.login-title{color:white;text-align:center;font-weight:900;font-size:22px;line-height:1.1;letter-spacing:-0.02em}
.login-motto{color:white;font-style:italic;opacity:0.9;text-align:center;font-size:15px;line-height:1.4;max-width:300px}
.login-card{background:white;border-radius:28px;padding:20px;width:100%;box-shadow:0 20px 60px rgba(0,0,0,0.25);display:flex;flex-direction:column;gap:14px}
.login-card label{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:var(--text-2);display:flex;gap:6px;align-items:center}
.login-card select,.login-card input{width:100%;height:60px;border-radius:16px;border:2px solid var(--border);padding:0 16px;font-size:16px;font-weight:700;background:#f8faff;outline:none}
.login-card select:focus,.login-card input:focus{border-color:var(--pc-blue);box-shadow:0 0 0 4px #eef2fb}
.pin-pad{display:flex;flex-wrap:wrap;gap:6px}
.pin-pad button{height:46px;min-width:52px;flex:1;border-radius:999px;border:1px solid var(--border);background:var(--surface-2);font-weight:700;font-size:16px}
.btn-primary{width:100%;height:60px;border-radius:16px;background:var(--pc-blue);color:white;font-weight:900;font-size:17px;border:none;display:flex;align-items:center;justify-content:center;gap:8px;box-shadow:0 8px 20px rgba(15,44,92,0.3)}
.secure-note{background:#eef2fb;border:1px solid var(--border);border-radius:12px;padding:10px;font-size:11px;display:flex;gap:8px;line-height:1.4}
.login-footer{color:rgba(255,255,255,0.6);font-size:10px;text-align:center;font-family:monospace;line-height:1.5}
.header{height:60px;background:rgba(255,255,255,0.95);backdrop-filter:blur(12px);border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;padding:0 12px;position:sticky;top:0;z-index:40;box-shadow:0 2px 16px rgba(15,44,92,0.06)}
.header-left{display:flex;align-items:center;gap:10px;min-width:0}
.header-logo{width:40px;height:40px;background:white;border:1px solid var(--border);border-radius:12px;display:flex;align-items:center;justify-content:center;overflow:hidden;flex-shrink:0}
.header-logo img{width:28px;height:28px;object-fit:contain}
.main{max-width:1280px;margin:0 auto;padding:12px;padding-bottom:90px}
.card{background:white;border:1px solid var(--border);border-radius:22px;padding:16px;box-shadow:0 4px 20px rgba(15,44,92,0.06);margin-bottom:16px}
.btn{height:48px;border-radius:14px;border:1px solid var(--border);background:white;font-weight:700;padding:0 16px;display:flex;align-items:center;justify-content:center;gap:8px;font-size:13px}
.btn-blue{background:var(--pc-blue);color:white;border-color:var(--pc-blue)}
.btn-green{background:var(--ok);color:white;border-color:var(--ok)}
.btn-red{background:var(--danger);color:white;border-color:var(--danger)}
.btn-yellow{background:var(--pc-yellow);color:var(--pc-blue);border-color:var(--pc-yellow)}
.bottom-nav{position:fixed;bottom:0;left:0;right:0;background:rgba(255,255,255,0.96);backdrop-filter:blur(16px);border-top:1px solid var(--border);display:flex;justify-content:space-around;padding:6px 4px calc(env(safe-area-inset-bottom,0px) + 6px);z-index:45;box-shadow:0 -8px 30px rgba(15,44,92,0.08)}
.bottom-nav button{flex:1;display:flex;flex-direction:column;align-items:center;gap:2px;padding:8px 4px;border-radius:14px;border:none;background:transparent;font-size:10px;font-weight:600;color:var(--text-2)}
.bottom-nav button.active{background:#eef2fb;color:var(--pc-blue)}
.toast{position:fixed;bottom:86px;left:50%;transform:translateX(-50%);background:#0f2c5c;color:white;padding:12px 20px;border-radius:999px;font-size:13px;z-index:80;max-width:90vw;box-shadow:0 10px 30px rgba(0,0,0,0.3);display:flex;gap:8px;align-items:center}
.calendar{display:grid;grid-template-columns:repeat(7,1fr);gap:4px}
.timeline{display:flex;flex-direction:column;gap:8px;max-height:400px;overflow:auto}
.timeline-item{display:flex;gap:10px;padding:12px;border:1px solid var(--border);border-radius:14px;background:#f8faff}
.modal{position:fixed;inset:0;background:rgba(0,0,0,0.5);backdrop-filter:blur(4px);display:flex;align-items:flex-end;justify-content:center;z-index:90;padding:0}
@media(min-width:768px){.modal{align-items:center;padding:20px}.modal-card{border-radius:20px !important}}
.modal-card{background:white;width:100%;max-width:640px;max-height:94vh;overflow:auto;border-radius:28px 28px 0 0;padding:20px;box-shadow:0 20px 60px rgba(0,0,0,0.3)}
.mono{font-family:monospace}
.badge{display:inline-flex;padding:2px 8px;border-radius:999px;font-size:10px;font-weight:700;border:1px solid var(--border);background:var(--surface-2)}
</style>
</head>
<body>
<div id="toast"></div>
<div id="app"></div>
<script>
var LOGO='${safeLogo}';
var LS_KEY='pc_alessandria_github_v1';
var HQ={lat:44.897036,lng:8.597517,address:'Strada Casalcermelli 49C, 15121 Alessandria',radius:150};
var DEFAULT_VOLUNTEERS=[
{id:'v1',name:'Mario',surname:'Rossi',role:'volontario',pin:'1234',cf:'RSSMRA80A01A001X',phone:'+39 333 1234567',email:'mario.rossi@pc-alessandria.it',qualifica:'Operatore Base',gruppo:'Gruppo Comunale',note:'Disponibile weekend',stato:'attivo',createdAt:Date.now()},
{id:'v2',name:'Laura',surname:'Bianchi',role:'volontario',pin:'5678',cf:'BNCLRA85B02B002Y',phone:'+39 333 7654321',email:'laura.bianchi@pc-alessandria.it',qualifica:'Caposquadra',gruppo:'Squadra A',note:'Caposquadra',stato:'attivo',createdAt:Date.now()},
{id:'c1',name:'Giuseppe',surname:'Verdi',role:'coordinatore',pin:'9999',cf:'VRDGPP70C03C003Z',phone:'+39 333 9999999',email:'coord@pc-alessandria.it',qualifica:'Coordinatore',gruppo:'Coordinamento',note:'Coordinatore',stato:'attivo',createdAt:Date.now()},
{id:'s1',name:'Anna',surname:'Neri',role:'servizio',pin:'0000',cf:'NRINNA75D04D004W',phone:'+39 0131 123456',email:'servizio@pc-alessandria.it',qualifica:'Servizio Comunale',gruppo:'Servizio Comunale',note:'Ufficio',stato:'attivo',createdAt:Date.now()}
];
var QUALIFICHE=['Volontario','Caposquadra','Autista','Operatore Radio','Operatore Base','Operatore TLC','Cinofilo','Sommozzatore','Antincendio','Logistica'];
var GRUPPI=['Gruppo Comunale','Squadra A','Squadra B','Squadra Logistica','Coordinamento','Servizio Comunale','TLC','Cinofili'];
function haversine(lat1,lon1,lat2,lon2){var R=6371e3;var toRad=function(d){return d*Math.PI/180};var dLat=toRad(lat2-lat1);var dLon=toRad(lon2-lon1);var a=Math.sin(dLat/2)*Math.sin(dLat/2)+Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*Math.sin(dLon/2)*Math.sin(dLon/2);return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));}
function fmtTime(ts){return new Date(ts).toLocaleString('it-IT',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});}
function fmtDate(ts){return new Date(ts).toLocaleDateString('it-IT');}
function fmtDur(ms){var m=Math.floor(ms/60000);var h=Math.floor(m/60);if(h>0) return h+'h '+m%60+'m';return m+' min';}
function daysInMonth(m,y){return new Date(y,m+1,0).getDate();}
function monthName(m){return ['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'][m];}
function genPin(){return String(Math.floor(1000+Math.random()*9000));}
var state={
user:null,
volunteers:[],
timbrature:[],
ferie:[],
reper:[],
chat:[],
allarmi:[],
positions:[],
emergency:null,
tab:'home',
coordTab:'dashboard',
schedaMonth:new Date().getMonth(),
schedaYear:new Date().getFullYear(),
selectedVolId:'',
pinInput:'',
toast:null,
loc:null,
countdown:30000,
filter:'',
selectedSchedaVol:null,
editingVol:null,
showAdd:false,
chatChannel:'generale',
chatInput:'',
ferieForm:{start:'',end:'',motivo:''},
reperForm:{days:[],orari:'18:00-08:00',note:''},
fineReport:'',
showFine:false,
ferieSub:'ferie',
revealedPins:{},
newVol:{name:'',surname:'',cf:'',phone:'',email:'',qualifica:'Operatore Base',gruppo:'Gruppo Comunale',note:''},
allarmeForm:{type:'Allerta Meteo',luogo:'',note:''}
};
function load(){
try{
var raw=localStorage.getItem(LS_KEY);
if(raw){
var d=JSON.parse(raw);
state.volunteers=d.volunteers||DEFAULT_VOLUNTEERS;
state.timbrature=d.timbrature||[];
state.ferie=d.ferie||[];
state.reper=d.reper||[];
state.chat=d.chat||[];
state.allarmi=d.allarmi||[];
state.positions=d.positions||[];
}else{
state.volunteers=JSON.parse(JSON.stringify(DEFAULT_VOLUNTEERS));
}
}catch(e){
state.volunteers=JSON.parse(JSON.stringify(DEFAULT_VOLUNTEERS));
}
if(!state.selectedVolId && state.volunteers.length) state.selectedVolId=state.volunteers[0].id;
}
function save(){
try{
localStorage.setItem(LS_KEY,JSON.stringify({volunteers:state.volunteers,timbrature:state.timbrature,ferie:state.ferie,reper:state.reper,chat:state.chat,allarmi:state.allarmi,positions:state.positions}));
}catch(e){}
}
function showToast(msg){
state.toast=msg;
render();
setTimeout(function(){state.toast=null;render();},4000);
}
function isCoordinator(){
return state.user && (state.user.role==='coordinatore' || state.user.role==='servizio');
}
function render(){
var toastEl=document.getElementById('toast');
if(state.toast){
toastEl.innerHTML='<div class="toast">✅ '+state.toast+'</div>';
toastEl.style.display='block';
}else{
toastEl.innerHTML='';
}
var root=document.getElementById('app');
if(!state.user){
renderLogin(root);
return;
}
if(isCoordinator()){
renderCoordinator(root);
}else{
renderVolunteer(root);
}
}
function renderLogin(root){
var selVol=state.volunteers.find(function(v){return v.id===state.selectedVolId;});
var html='';
html+='<div class="login-wrap"><div class="login-bg"></div><div class="login-content">';
html+='<div style="display:flex;gap:8px;align-items:center;color:rgba(255,255,255,0.7);font-size:10px;font-weight:700;letter-spacing:0.15em;text-transform:uppercase">🔒 Accesso sicuro • PIN protetti • GitHub Pages</div>';
html+='<div class="login-logo"><img src="'+LOGO+'" alt="logo ufficiale"/></div>';
html+='<div class="login-title">PROTEZIONE CIVILE<br/>CITTÀ DI ALESSANDRIA</div>';
html+='<div style="color:rgba(255,255,255,0.8);font-size:11px;font-weight:600;letter-spacing:0.1em">Gruppo Comunale Volontari</div>';
html+='<div class="login-motto">"Ovunque, per tutti -<br/>Presenti quando conta."</div>';
html+='<div class="login-card">';
html+='<label>👥 Seleziona il tuo nome - solo nomi, no PIN visibili</label>';
html+='<select id="vol-select" onchange="handleVolSelect()">'+state.volunteers.map(function(v){return '<option value="'+v.id+'" '+(v.id===state.selectedVolId?'selected':'')+'>'+v.name+' '+(v.surname||'')+' • '+(v.role==='coordinatore'?'Coordinatore':v.role==='servizio'?'Servizio':'Volontario')+' • '+v.qualifica+'</option>';}).join('')+'</select>';
if(selVol){
html+='<div id="vol-preview" style="display:flex;gap:10px;align-items:center;background:#f8faff;border:1px solid var(--border);border-radius:12px;padding:10px"><div style="width:36px;height:36px;border-radius:50%;background:var(--pc-blue);color:white;display:flex;align-items:center;justify-content:center;font-weight:700">'+selVol.name[0]+(selVol.surname?selVol.surname[0]:'')+'</div><div style="flex:1;min-width:0"><div style="font-weight:700;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+selVol.name+' '+(selVol.surname||'')+' • '+selVol.gruppo+'</div><div style="font-size:11px;color:var(--text-2)">'+selVol.qualifica+' • PIN protetto ••••</div></div><div style="width:28px;height:28px;border-radius:50%;background:white;border:1px solid var(--border);display:flex;align-items:center;justify-content:center">🔒</div></div>';
}else{
html+='<div id="vol-preview"></div>';
}
html+='<label>🔒 PIN segreto (4 cifre) - tastierino numerico</label>';
html+='<input id="pin-input" type="password" inputmode="numeric" value="'+state.pinInput+'" placeholder="••••" oninput="handlePinInput(this.value)" onkeydown="if(event.key===\'Enter\') doLogin()" style="text-align:center;letter-spacing:0.5em;font-size:28px"/>';
html+='<div class="pin-pad">'+[1,2,3,4,5,6,7,8,9,0].map(function(n){return '<button onclick="handlePinPad(\''+n+'\')">'+n+'</button>';}).join('')+'<button onclick="handlePinPad(\'clear\')" style="background:white">Canc</button></div>';
html+='<button onclick="doLogin()" class="btn-primary">✅ ENTRA IN SERVIZIO</button>';
html+='<div class="secure-note">🛡️ <span><b>Sicurezza PIN:</b> in login vedi solo nomi. PIN coperto ••••. Solo Coord/Servizio vedono PIN con occhio + copia in schede. LocalStorage per GitHub Pages.</span></div>';
html+='</div>';
html+='<div class="login-footer">Sede '+HQ.address+' • '+HQ.lat+', '+HQ.lng+' • Raggio 150m<br/>GitHub Pages • PWA installabile • Dati in localStorage<br/>Apri da: https://TUO-USERNAME.github.io/REPO/</div>';
html+='</div></div>';
root.innerHTML=html;
var inp=document.getElementById('pin-input');
if(inp) inp.focus();
}
function handleVolSelect(){
var sel=document.getElementById('vol-select');
if(sel){state.selectedVolId=sel.value;state.pinInput='';render();}
}
function handlePinInput(v){
state.pinInput=v.slice(0,4);
var inp=document.getElementById('pin-input');
if(inp && inp.value!==state.pinInput) inp.value=state.pinInput;
}
function handlePinPad(n){
if(n==='clear'){state.pinInput='';}
else{if(state.pinInput.length<4) state.pinInput+=n;}
render();
var inp=document.getElementById('pin-input');
if(inp){inp.value=state.pinInput;inp.focus();}
if(state.pinInput.length===4) setTimeout(function(){doLogin();},300);
}
function doLogin(){
var selVol=state.volunteers.find(function(v){return v.id===state.selectedVolId;});
if(!selVol){showToast('Seleziona volontario');return;}
if(state.pinInput!==selVol.pin){showToast('PIN errato per '+selVol.name+' (demo: '+selVol.pin+')');return;}
state.user=selVol;
state.pinInput='';
render();
showToast('Benvenuto '+selVol.name+' - Presenti quando conta');
try{if(navigator.vibrate) navigator.vibrate(20);}catch(e){}
}
function doLogout(){
state.user=null;
state.emergency=null;
render();
}
function getLocation(cb){
if(!navigator.geolocation){cb(null,'Geoloc non supportata');return;}
navigator.geolocation.getCurrentPosition(function(pos){
var d={lat:pos.coords.latitude,lng:pos.coords.longitude,acc:pos.coords.accuracy,ts:Date.now()};
state.loc=d;
cb(d,null);
},function(err){cb(null,err.message);},{enableHighAccuracy:true,timeout:10000,maximumAge:0});
}
function doTimbra(tipo){
getLocation(function(loc,err){
if(err){showToast('Errore GPS: '+err);return;}
if(tipo!=='emergenza'){
var dist=haversine(loc.lat,loc.lng,HQ.lat,HQ.lng);
if(dist>HQ.radius){showToast('Fuori sede: '+Math.round(dist)+'m > '+HQ.radius+'m (richiesto entro 150m da 44.897036,8.597517)');return;}
}
var t={volunteerId:state.user.id,volName:state.user.name+' '+(state.user.surname||''),type:tipo,ts:Date.now(),lat:loc.lat,lng:loc.lng,acc:loc.acc,status:'ok',dist:tipo!=='emergenza'?haversine(loc.lat,loc.lng,HQ.lat,HQ.lng):null};
state.timbrature.unshift(t);
if(tipo==='emergenza'){
state.emergency={active:true,since:Date.now(),lastSend:Date.now()};
state.countdown=30000;
}
save();
render();
showToast(tipo==='entrata'?'Entrata registrata ✅':tipo==='uscita'?'Uscita registrata':tipo==='emergenza'?'🚨 EMERGENZA ATTIVATA - invio GPS ogni 30s (30min prod)':'Timbratura');
try{if(navigator.vibrate) navigator.vibrate([30,20,30]);}catch(e){}
});
}
function triggerPosSend(){
getLocation(function(loc,err){
if(err) return;
var p={volunteerId:state.user.id,volName:state.user.name+' '+(state.user.surname||''),lat:loc.lat,lng:loc.lng,acc:loc.acc,ts:Date.now(),emergenza:true};
state.positions.unshift(p);
if(state.emergency) state.emergency.lastSend=Date.now();
save();
render();
showToast('📍 Posizione emergenza inviata');
});
}
function fineEmergenza(){
var el=document.getElementById('fine-report');
var rep=el?el.value:state.fineReport;
if(!rep){showToast('Inserisci report fine emergenza');return;}
var t={volunteerId:state.user.id,volName:state.user.name+' '+(state.user.surname||''),type:'fine',ts:Date.now(),report:rep,lat:state.loc?state.loc.lat:HQ.lat,lng:state.loc?state.loc.lng:HQ.lng,status:'ok'};
state.timbrature.unshift(t);
state.emergency=null;
state.showFine=false;
state.fineReport='';
save();
render();
showToast('Emergenza chiusa - report salvato');
}
function openFine(){state.showFine=true;render();}
function closeFine(){state.showFine=false;render();}
function handleFineInput(v){state.fineReport=v;}
function doFerie(){
var sEl=document.getElementById('ferie-start');
var eEl=document.getElementById('ferie-end');
var mEl=document.getElementById('ferie-motivo');
var subEl=document.getElementById('ferie-sub');
var start=sEl?sEl.value:state.ferieForm.start;
var end=eEl?eEl.value:state.ferieForm.end;
var motivo=mEl?mEl.value:state.ferieForm.motivo;
var tipo=subEl?subEl.value:state.ferieSub;
if(!start||!end){showToast('Inserisci date');return;}
var f={volunteerId:state.user.id,volName:state.user.name+' '+(state.user.surname||''),type:tipo,start:start,end:end,motivo:motivo,ts:Date.now(),status:'in_attesa'};
state.ferie.unshift(f);
state.ferieForm={start:'',end:'',motivo:''};
save();
render();
showToast('Richiesta inviata');
}
function toggleReperDay(d){
var idx=state.reperForm.days.indexOf(d);
if(idx===-1) state.reperForm.days.push(d);
else state.reperForm.days.splice(idx,1);
var orariEl=document.getElementById('reper-orari');
var noteEl=document.getElementById('reper-note');
if(orariEl) state.reperForm.orari=orariEl.value;
if(noteEl) state.reperForm.note=noteEl.value;
render();
}
function doChat(){
var inputEl=document.getElementById('chat-input');
var msg=inputEl?inputEl.value:state.chatInput;
if(!msg || !msg.trim()) return;
var m={channel:state.chatChannel,authorId:state.user.id,authorName:state.user.name+' '+(state.user.surname||''),role:state.user.role,message:msg.trim(),ts:Date.now()};
state.chat.push(m);
state.chatInput='';
save();
render();
}
function handleChatInput(v){
state.chatInput=v;
}
function doAllarme(){
var luogoEl=document.getElementById('allarme-luogo');
var noteEl=document.getElementById('allarme-note');
var typeEl=document.getElementById('allarme-type');
var luogo=luogoEl?luogoEl.value:state.allarmeForm.luogo;
var note=noteEl?noteEl.value:state.allarmeForm.note;
var type=typeEl?typeEl.value:state.allarmeForm.type;
if(!luogo){showToast('Inserisci luogo');return;}
var a={type:type,luogo:luogo,note:note,ts:Date.now(),author:state.user.name+' '+(state.user.surname||'')};
state.allarmi.unshift(a);
state.allarmeForm={type:'Allerta Meteo',luogo:'',note:''};
save();
render();
showToast('ALLERTAMENTO INVIATO a tutti i volontari: '+type);
}
function avallaTimbratura(idx){
var t=state.timbrature[idx];
if(!t) return;
t.status='avallata';
save();
render();
showToast('Timbratura avallata');
}
function togglePinReveal(id){
state.revealedPins[id]=!state.revealedPins[id];
render();
}
function copyPin(pin){
try{
var ta=document.createElement('textarea');
ta.value=pin;
document.body.appendChild(ta);
ta.select();
document.execCommand('copy');
document.body.removeChild(ta);
showToast('PIN '+pin+' copiato');
}catch(e){
showToast('PIN: '+pin);
}
}
function openAddVol(){
state.showAdd=!state.showAdd;
render();
}
function handleNewVol(field,val){
state.newVol[field]=val;
}
function doAddVol(){
if(!state.newVol.name || !state.newVol.surname){showToast('Nome e cognome obbligatori');return;}
var pin=genPin();
var vol={id:'v-'+Date.now(),name:state.newVol.name,surname:state.newVol.surname,role:'volontario',pin:pin,cf:state.newVol.cf,phone:state.newVol.phone,email:state.newVol.email,qualifica:state.newVol.qualifica,gruppo:state.newVol.gruppo||'Gruppo Comunale',note:state.newVol.note,stato:'attivo',createdAt:Date.now()};
state.volunteers.push(vol);
state.newVol={name:'',surname:'',cf:'',phone:'',email:'',qualifica:'Operatore Base',gruppo:'Gruppo Comunale',note:''};
state.showAdd=false;
save();
render();
showToast('Volontario creato - PIN: '+pin+' (visibile in Gestione)');
}
function openVolunteerScheda(id){
var v=state.volunteers.find(function(x){return x.id===id;});
if(!v) return;
state.selectedSchedaVol=v;
render();
}
function closeScheda(){
state.selectedSchedaVol=null;
render();
}
function openEditVolunteer(id){
var v=state.volunteers.find(function(x){return x.id===id;});
if(!v) return;
state.editingVol=JSON.parse(JSON.stringify(v));
render();
}
function saveEditVolunteer(){
var nameEl=document.getElementById('edit-v-name');
var surnameEl=document.getElementById('edit-v-surname');
var cfEl=document.getElementById('edit-v-cf');
var phoneEl=document.getElementById('edit-v-phone');
var emailEl=document.getElementById('edit-v-email');
var qualEl=document.getElementById('edit-v-qual');
var gruppoEl=document.getElementById('edit-v-gruppo');
var statoEl=document.getElementById('edit-v-stato');
var noteEl=document.getElementById('edit-v-note');
if(nameEl) state.editingVol.name=nameEl.value;
if(surnameEl) state.editingVol.surname=surnameEl.value;
if(cfEl) state.editingVol.cf=cfEl.value;
if(phoneEl) state.editingVol.phone=phoneEl.value;
if(emailEl) state.editingVol.email=emailEl.value;
if(qualEl) state.editingVol.qualifica=qualEl.value;
if(gruppoEl) state.editingVol.gruppo=gruppoEl.value;
if(statoEl) state.editingVol.stato=statoEl.value;
if(noteEl) state.editingVol.note=noteEl.value;
var idx=state.volunteers.findIndex(function(v){return v.id===state.editingVol.id;});
if(idx!==-1) state.volunteers[idx]=state.editingVol;
if(state.user && state.user.id===state.editingVol.id) state.user=state.editingVol;
if(state.selectedSchedaVol && state.selectedSchedaVol.id===state.editingVol.id) state.selectedSchedaVol=state.editingVol;
state.editingVol=null;
save();
render();
showToast('Volontario aggiornato');
}
function deleteVolunteer(id){
if(state.volunteers.length<=1){showToast('Non puoi eliminare ultimo volontario');return;}
if(!confirm('Eliminare volontario? Azione irreversibile')) return;
state.volunteers=state.volunteers.filter(function(v){return v.id!==id;});
if(state.selectedVolId===id) state.selectedVolId=state.volunteers[0]?state.volunteers[0].id:'';
state.editingVol=null;
state.selectedSchedaVol=null;
save();
render();
showToast('Volontario eliminato');
}
function regenPin(){
if(!state.editingVol) return;
state.editingVol.pin=genPin();
render();
}
function renderVolunteer(root){
var isActive=state.timbrature.some(function(t){return t.volunteerId===state.user.id && t.type!=='fine' && Date.now()-t.ts < 8*3600*1000;});
var myTimb=state.timbrature.filter(function(t){return t.volunteerId===state.user.id;});
var myPos=state.positions.filter(function(p){return p.volunteerId===state.user.id;});
var html='';
html+='<div class="header"><div class="header-left"><div class="header-logo"><img src="'+LOGO+'"/></div><div><div style="font-weight:900;font-size:12px">'+state.user.name+' '+(state.user.surname||'')+'</div><div style="font-size:10px;color:var(--text-2)">'+state.user.qualifica+' • '+state.user.gruppo+'</div></div></div><div style="display:flex;gap:6px"><button class="btn" onclick="doLogout()">Esci</button></div></div>';
html+='<div class="main">';
html+='<div class="card"><div style="display:flex;justify-content:space-between;align-items:center"><div><div style="font-weight:900;font-size:16px">Ovunque, per tutti</div><div style="font-size:12px;color:var(--text-2);font-style:italic">Presenti quando conta.</div></div><div style="text-align:right;font-size:10px;font-family:monospace">'+HQ.lat+', '+HQ.lng+'<br/>Raggio '+HQ.radius+'m<br/>'+(state.loc?Math.round(haversine(state.loc.lat,state.loc.lng,HQ.lat,HQ.lng))+'m':'GPS --')+'</div></div>';
html+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px">';
html+='<button class="btn btn-blue" onclick="doTimbra(\\'entrata\\')">📍 Entrata</button>';
html+='<button class="btn" onclick="doTimbra(\\'uscita\\')">🚪 Uscita</button>';
html+='</div>';
html+='<button class="btn btn-red" style="width:100%;margin-top:8px" onclick="doTimbra(\\'emergenza\\')">🚨 EMERGENZA - Avvia SOS</button>';
if(state.emergency && state.emergency.active){
html+='<div style="margin-top:12px;background:#fff0f0;border:1px solid #f5c2c2;border-radius:12px;padding:12px"><div style="font-weight:900;color:var(--danger)">🚨 EMERGENZA ATTIVA</div><div style="font-size:11px;margin-top:4px">Invio GPS ogni 30s (demo) - 30min prod. Countdown: '+Math.ceil(state.countdown/1000)+'s</div><div style="display:flex;gap:8px;margin-top:8px"><button class="btn btn-blue" onclick="triggerPosSend()">📍 Invia ora</button><button class="btn btn-green" onclick="openFine()">✅ Chiudi</button></div></div>';
}
html+='</div>';
html+='<div class="card"><div style="font-weight:700;font-size:13px">📅 Schede mese per mese - Le tue ore</div><div style="display:flex;gap:8px;margin-top:8px"><select id="scheda-month" onchange="state.schedaMonth=parseInt(this.value);render()" style="flex:1;height:40px;border-radius:10px;border:1px solid var(--border);padding:0 8px">'+Array.from({length:12},function(_,i){return '<option value="'+i+'" '+(i===state.schedaMonth?'selected':'')+'>'+monthName(i)+'</option>';}).join('')+'</select><input type="number" id="scheda-year" value="'+state.schedaYear+'" onchange="state.schedaYear=parseInt(this.value);render()" style="width:90px;height:40px;border-radius:10px;border:1px solid var(--border);padding:0 8px"/></div>';
var filtered=myTimb.filter(function(t){var d=new Date(t.ts);return d.getMonth()===state.schedaMonth && d.getFullYear()===state.schedaYear;});
var totalMs=0;
for(var i=0;i<filtered.length-1;i++){if(filtered[i].type==='uscita' && filtered[i+1].type==='entrata'){totalMs+=filtered[i].ts-filtered[i+1].ts;}}
html+='<div style="margin-top:10px;font-size:12px">Ore totali: <b>'+fmtDur(totalMs)+'</b> • Timbrature: '+filtered.length+'</div>';
html+='<div class="timeline" style="margin-top:10px">'+filtered.slice(0,30).map(function(t){return '<div class="timeline-item"><div style="font-size:20px">'+(t.type==='entrata'?'🟢':t.type==='uscita'?'🔴':t.type==='emergenza'?'🚨':'✅')+'</div><div style="flex:1;min-width:0"><div style="font-weight:700;font-size:12px">'+t.type.toUpperCase()+' • '+fmtTime(t.ts)+'</div><div style="font-size:11px;color:var(--text-2)">'+(t.dist!==null?Math.round(t.dist)+'m da sede • ':'')+(t.lat? t.lat.toFixed(5)+','+t.lng.toFixed(5):'')+'</div></div></div>';}).join('')+'</div>';
html+='</div>';
html+='<div class="card"><div style="font-weight:700;font-size:13px">💬 Chat locale - '+state.chatChannel+'</div><div style="display:flex;gap:6px;margin-top:8px">'+['generale','emergenze','coordinamento'].map(function(ch){return '<button class="btn '+(state.chatChannel===ch?'btn-blue':'')+'" style="flex:1" onclick="state.chatChannel=\\''+ch+'\\';render()">'+ch+'</button>';}).join('')+'</div><div class="timeline" style="margin-top:10px;max-height:260px">'+state.chat.filter(function(m){return m.channel===state.chatChannel;}).slice(-50).map(function(m){return '<div style="padding:8px;border-bottom:1px solid var(--border)"><div style="font-size:10px;color:var(--text-2)">'+m.authorName+' • '+fmtTime(m.ts)+'</div><div style="font-size:13px;margin-top:2px">'+m.message+'</div></div>';}).join('')+'</div><div style="display:flex;gap:6px;margin-top:8px"><input id="chat-input" value="'+(state.chatInput||'').replace(/"/g,'&quot;')+'" oninput="handleChatInput(this.value)" onkeydown="if(event.key===\'Enter\') doChat()" placeholder="Messaggio..." style="flex:1;height:44px;border-radius:12px;border:1px solid var(--border);padding:0 12px"/><button class="btn btn-blue" onclick="doChat()">Invia</button></div></div>';
html+='<div class="card"><div style="font-weight:700;font-size:13px">📅 Ferie / Reperibilità / Permessi</div><div style="display:flex;gap:6px;margin-top:8px">'+['ferie','permesso','reper'].map(function(t){return '<button class="btn '+(state.ferieSub===t?'btn-blue':'')+'" onclick="state.ferieSub=\\''+t+'\\';render()" style="flex:1">'+t+'</button>';}).join('')+'</div>';
if(state.ferieSub==='reper'){
html+='<div style="margin-top:10px"><div style="font-size:11px;font-weight:700">Giorni</div><div style="display:flex;flex-wrap:wrap;gap:4px;margin-top:6px">'+['Lun','Mar','Mer','Gio','Ven','Sab','Dom'].map(function(d){return '<button class="btn '+(state.reperForm.days.includes(d)?'btn-blue':'')+'" onclick="toggleReperDay(\\''+d+'\\')" style="height:36px">'+d+'</button>';}).join('')+'</div><input id="reper-orari" value="'+state.reperForm.orari+'" placeholder="18:00-08:00" style="margin-top:8px;width:100%;height:40px;border-radius:10px;border:1px solid var(--border);padding:0 10px"/><textarea id="reper-note" placeholder="Note" style="margin-top:6px;width:100%;min-height:60px;border-radius:10px;border:1px solid var(--border);padding:8px 10px">'+state.reperForm.note+'</textarea><button class="btn btn-blue" style="width:100%;margin-top:8px" onclick="doFerie()">Invia disponibilità</button></div>';
}else{
html+='<div style="margin-top:10px;display:grid;gap:8px"><input id="ferie-start" type="date" value="'+state.ferieForm.start+'" style="height:44px;border-radius:10px;border:1px solid var(--border);padding:0 10px"/><input id="ferie-end" type="date" value="'+state.ferieForm.end+'" style="height:44px;border-radius:10px;border:1px solid var(--border);padding:0 10px"/><input id="ferie-motivo" value="'+state.ferieForm.motivo+'" placeholder="Motivo" style="height:44px;border-radius:10px;border:1px solid var(--border);padding:0 10px"/><select id="ferie-sub" style="height:44px;border-radius:10px;border:1px solid var(--border);padding:0 10px"><option value="ferie" '+(state.ferieSub==='ferie'?'selected':'')+'>Ferie</option><option value="permesso" '+(state.ferieSub==='permesso'?'selected':'')+'>Permesso</option></select><button class="btn btn-blue" onclick="doFerie()">Invia richiesta</button></div>';
}
html+='<div class="timeline" style="margin-top:10px">'+state.ferie.filter(function(f){return f.volunteerId===state.user.id;}).map(function(f){return '<div class="timeline-item"><div><b>'+f.type+'</b> • '+f.start+' → '+f.end+'<br/><span style="font-size:11px;color:var(--text-2)">'+f.motivo+' • '+f.status+'</span></div></div>';}).join('')+'</div>';
html+='</div>';
if(state.showFine){
html+='<div class="modal" onclick="closeFine()"><div class="modal-card" onclick="event.stopPropagation()"><div style="font-weight:900;font-size:16px">Chiudi emergenza - Report</div><textarea id="fine-report" oninput="handleFineInput(this.value)" placeholder="Descrivi attività svolta..." style="width:100%;min-height:120px;margin-top:10px;border-radius:12px;border:1px solid var(--border);padding:10px">'+state.fineReport+'</textarea><div style="display:flex;gap:8px;margin-top:10px"><button class="btn" onclick="closeFine()" style="flex:1">Annulla</button><button class="btn btn-green" onclick="fineEmergenza()" style="flex:1">✅ Chiudi emergenza</button></div></div></div>';
}
html+='</div>';
html+='<div class="bottom-nav"><button class="active">🏠<span>Home</span></button><button>📍<span>Timbra</span></button><button>📅<span>Ferie</span></button><button>💬<span>Chat</span></button><button>🏅<span>Schede</span></button></div>';
root.innerHTML=html;
}
function renderCoordinator(root){
var html='';
html+='<div class="header"><div class="header-left"><div class="header-logo"><img src="'+LOGO+'"/></div><div><div style="font-weight:900;font-size:12px">'+state.user.name+' '+(state.user.surname||'')+' • COORD</div><div style="font-size:10px;color:var(--text-2)">Coordinamento • Sede '+HQ.lat+','+HQ.lng+' • 150m</div></div></div><div style="display:flex;gap:6px"><button class="btn" onclick="doLogout()">Esci</button></div></div>';
html+='<div class="main">';
html+='<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:12px">'+[
{key:'dashboard',label:'Dashboard',icon:'📊'},
{key:'volontari',label:'Volontari',icon:'👥'},
{key:'timbrature',label:'Timbrature',icon:'📍'},
{key:'allarmi',label:'Allarmi',icon:'🚨'},
{key:'chat',label:'Chat',icon:'💬'},
{key:'posizioni',label:'Posizioni',icon:'🛰️'},
{key:'ferie',label:'Ferie',icon:'📅'}
].map(function(t){return '<button class="btn '+(state.coordTab===t.key?'btn-blue':'')+'" onclick="state.coordTab=\\''+t.key+'\\';render()">'+t.icon+' '+t.label+'</button>';}).join('')+'</div>';
if(state.coordTab==='dashboard'){
var totVol=state.volunteers.length;
var attivi=state.timbrature.filter(function(t){return Date.now()-t.ts<24*3600*1000;}).length;
html+='<div class="card"><div style="font-weight:900;font-size:18px">Dashboard Coordinatore - Presenti quando conta</div><div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-top:12px"><div style="background:#eef2fb;border:1px solid var(--border);border-radius:14px;padding:12px;text-align:center"><div style="font-size:22px;font-weight:900">'+totVol+'</div><div style="font-size:10px">Volontari</div></div><div style="background:#eef2fb;border:1px solid var(--border);border-radius:14px;padding:12px;text-align:center"><div style="font-size:22px;font-weight:900">'+state.timbrature.length+'</div><div style="font-size:10px">Timbrature</div></div><div style="background:#eef2fb;border:1px solid var(--border);border-radius:14px;padding:12px;text-align:center"><div style="font-size:22px;font-weight:900">'+state.allarmi.length+'</div><div style="font-size:10px">Allarmi</div></div></div>';
html+='<div style="margin-top:12px"><div style="font-weight:700;font-size:13px">Ultime timbrature</div><div class="timeline" style="margin-top:8px">'+state.timbrature.slice(0,10).map(function(t,i){return '<div class="timeline-item"><div style="font-size:18px">'+(t.type==='emergenza'?'🚨':t.type==='entrata'?'🟢':'🔵')+'</div><div style="flex:1"><div style="font-weight:700;font-size:12px">'+t.volName+' • '+t.type+' • '+fmtTime(t.ts)+'</div><div style="font-size:11px;color:var(--text-2)">'+Math.round(t.dist||0)+'m • '+t.lat.toFixed(4)+','+t.lng.toFixed(4)+' • '+t.status+'</div></div><button class="btn" style="height:32px" onclick="avallaTimbratura('+i+')">Avalla</button></div>';}).join('')+'</div></div>';
html+='<div class="card"><div style="font-weight:700">🚨 Invia allertamento</div><div style="display:grid;gap:8px;margin-top:8px"><select id="allarme-type" style="height:44px;border-radius:10px;border:1px solid var(--border);padding:0 10px"><option>Allerta Meteo</option><option>Allerta Idrogeologica</option><option>Emergenza Neve</option><option>Incendio Boschivo</option><option>Ricerca Persona</option><option>Esercitazione</option></select><input id="allarme-luogo" value="'+state.allarmeForm.luogo+'" placeholder="Luogo intervento" style="height:44px;border-radius:10px;border:1px solid var(--border);padding:0 10px"/><textarea id="allarme-note" placeholder="Note" style="min-height:70px;border-radius:10px;border:1px solid var(--border);padding:10px">'+state.allarmeForm.note+'</textarea><button class="btn btn-red" onclick="doAllarme()">🚨 INVIA ALLERTAMENTO A TUTTI</button></div></div>';
html+='</div>';
}else if(state.coordTab==='volontari'){
html+='<div class="card"><div style="display:flex;justify-content:space-between;align-items:center"><div style="font-weight:900;font-size:16px">👥 Gestione volontari - Modifica / PIN con occhio</div><button class="btn btn-blue" onclick="openAddVol()">+ Aggiungi</button></div><input placeholder="Filtra per nome, qualifica, gruppo..." value="'+state.filter+'" oninput="handleFilter(this.value)" style="margin-top:10px;width:100%;height:44px;border-radius:12px;border:1px solid var(--border);padding:0 12px"/>';
if(state.showAdd){
html+='<div style="margin-top:12px;background:#f8faff;border:1px solid var(--border);border-radius:16px;padding:12px;display:grid;gap:8px"><div style="font-weight:700;font-size:12px">Nuovo volontario</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px"><input placeholder="Nome" value="'+state.newVol.name+'" oninput="handleNewVol(\\'name\\',this.value)" style="height:40px;border-radius:10px;border:1px solid var(--border);padding:0 8px"/><input placeholder="Cognome" value="'+state.newVol.surname+'" oninput="handleNewVol(\\'surname\\',this.value)" style="height:40px;border-radius:10px;border:1px solid var(--border);padding:0 8px"/></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px"><input placeholder="CF" value="'+state.newVol.cf+'" oninput="handleNewVol(\\'cf\\',this.value)" style="height:40px;border-radius:10px;border:1px solid var(--border);padding:0 8px"/><input placeholder="Telefono" value="'+state.newVol.phone+'" oninput="handleNewVol(\\'phone\\',this.value)" style="height:40px;border-radius:10px;border:1px solid var(--border);padding:0 8px"/></div><input placeholder="Email" value="'+state.newVol.email+'" oninput="handleNewVol(\\'email\\',this.value)" style="height:40px;border-radius:10px;border:1px solid var(--border);padding:0 8px"/><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px"><select onchange="handleNewVol(\\'qualifica\\',this.value)" style="height:40px;border-radius:10px;border:1px solid var(--border);padding:0 8px">'+QUALIFICHE.map(function(q){return '<option '+(q===state.newVol.qualifica?'selected':'')+'>'+q+'</option>';}).join('')+'</select><select onchange="handleNewVol(\\'gruppo\\',this.value)" style="height:40px;border-radius:10px;border:1px solid var(--border);padding:0 8px">'+GRUPPI.map(function(g){return '<option '+(g===state.newVol.gruppo?'selected':'')+'>'+g+'</option>';}).join('')+'</select></div><textarea placeholder="Note" oninput="handleNewVol(\\'note\\',this.value)" style="min-height:60px;border-radius:10px;border:1px solid var(--border);padding:8px">'+state.newVol.note+'</textarea><button class="btn btn-green" onclick="doAddVol()">✅ Crea volontario con PIN auto</button></div>';
}
html+='<div style="margin-top:12px;display:grid;gap:8px">'+state.volunteers.filter(function(v){return !state.filter || (v.name+' '+v.surname+' '+v.qualifica+' '+v.gruppo).toLowerCase().includes(state.filter.toLowerCase());}).map(function(v){var revealed=state.revealedPins[v.id];return '<div style="border:1px solid var(--border);border-radius:14px;padding:12px;background:#f8faff;display:flex;gap:10px;align-items:center"><div style="width:40px;height:40px;border-radius:50%;background:var(--pc-blue);color:white;display:flex;align-items:center;justify-content:center;font-weight:700">'+v.name[0]+(v.surname?v.surname[0]:'')+'</div><div style="flex:1;min-width:0"><div style="font-weight:700;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+v.name+' '+(v.surname||'')+' • '+v.gruppo+'</div><div style="font-size:11px;color:var(--text-2)">'+v.qualifica+' • '+v.stato+' • PIN: '+(revealed?v.pin:'••••')+'</div></div><div style="display:flex;gap:4px"><button class="btn" style="height:36px" onclick="togglePinReveal(\\''+v.id+'\\')">'+(revealed?'🙈':'👁️')+'</button><button class="btn" style="height:36px" onclick="copyPin(\\''+v.pin+'\\')">📋</button><button class="btn btn-blue" style="height:36px" onclick="openVolunteerScheda(\\''+v.id+'\\')">Scheda</button><button class="btn" style="height:36px" onclick="openEditVolunteer(\\''+v.id+'\\')">✏️</button></div></div>';}).join('')+'</div></div>';
}else if(state.coordTab==='timbrature'){
html+='<div class="card"><div style="font-weight:900">📍 Tutte le timbrature - mese per mese</div><div style="display:flex;gap:8px;margin-top:8px"><select onchange="state.schedaMonth=parseInt(this.value);render()" style="flex:1;height:40px;border-radius:10px;border:1px solid var(--border);padding:0 8px">'+Array.from({length:12},function(_,i){return '<option value="'+i+'" '+(i===state.schedaMonth?'selected':'')+'>'+monthName(i)+'</option>';}).join('')+'</select><input type="number" value="'+state.schedaYear+'" onchange="state.schedaYear=parseInt(this.value);render()" style="width:90px;height:40px;border-radius:10px;border:1px solid var(--border);padding:0 8px"/></div><div class="timeline" style="margin-top:10px">'+state.timbrature.map(function(t,i){return '<div class="timeline-item"><div style="font-size:18px">'+(t.type==='emergenza'?'🚨':t.type==='entrata'?'🟢':t.type==='uscita'?'🔴':'✅')+'</div><div style="flex:1"><div style="font-weight:700;font-size:12px">'+t.volName+' • '+t.type+' • '+fmtTime(t.ts)+'</div><div style="font-size:11px;color:var(--text-2)">'+(t.dist?Math.round(t.dist)+'m • ':'')+t.lat.toFixed(5)+','+t.lng.toFixed(5)+' • '+t.status+'</div>'+(t.report?'<div style="font-size:11px;margin-top:4px;background:white;border:1px solid var(--border);border-radius:8px;padding:6px">'+t.report+'</div>':'')+'</div><button class="btn" style="height:32px" onclick="avallaTimbratura('+i+')">Avalla</button></div>';}).join('')+'</div></div>';
}else if(state.coordTab==='chat'){
html+='<div class="card"><div style="font-weight:700">💬 Chat - Coordinamento</div><div style="display:flex;gap:6px;margin-top:8px">'+['generale','emergenze','coordinamento'].map(function(ch){return '<button class="btn '+(state.chatChannel===ch?'btn-blue':'')+'" style="flex:1" onclick="state.chatChannel=\\''+ch+'\\';render()">'+ch+'</button>';}).join('')+'</div><div class="timeline" style="margin-top:10px">'+state.chat.filter(function(m){return m.channel===state.chatChannel;}).slice(-100).map(function(m){return '<div style="padding:8px;border-bottom:1px solid var(--border)"><div style="font-size:10px;color:var(--text-2)">'+m.authorName+' • '+fmtTime(m.ts)+' • '+m.role+'</div><div style="font-size:13px">'+m.message+'</div></div>';}).join('')+'</div><div style="display:flex;gap:6px;margin-top:8px"><input id="chat-input" value="'+(state.chatInput||'').replace(/"/g,'&quot;')+'" oninput="handleChatInput(this.value)" onkeydown="if(event.key===\'Enter\') doChat()" placeholder="Messaggio..." style="flex:1;height:44px;border-radius:12px;border:1px solid var(--border);padding:0 12px"/><button class="btn btn-blue" onclick="doChat()">Invia</button></div></div>';
}else if(state.coordTab==='posizioni'){
html+='<div class="card"><div style="font-weight:700">🛰️ Posizioni emergenza - invio ogni 30min (demo 30s, prod 30min)</div><div class="timeline" style="margin-top:10px">'+state.positions.map(function(p){return '<div class="timeline-item"><div>📍</div><div style="flex:1"><div style="font-weight:700;font-size:12px">'+p.volName+' • '+fmtTime(p.ts)+'</div><div style="font-size:11px;color:var(--text-2)">'+p.lat.toFixed(5)+','+p.lng.toFixed(5)+' • acc '+Math.round(p.acc)+'m</div></div></div>';}).join('')+'</div></div>';
}else if(state.coordTab==='allarmi'){
html+='<div class="card"><div style="font-weight:700">🚨 Allarmi inviati</div><div class="timeline" style="margin-top:10px">'+state.allarmi.map(function(a){return '<div class="timeline-item"><div>🚨</div><div style="flex:1"><div style="font-weight:700;font-size:12px">'+a.type+' • '+fmtTime(a.ts)+' • '+a.author+'</div><div style="font-size:11px">'+a.luogo+'</div><div style="font-size:11px;color:var(--text-2)">'+a.note+'</div></div></div>';}).join('')+'</div></div>';
}else if(state.coordTab==='ferie'){
html+='<div class="card"><div style="font-weight:700">📅 Richieste ferie / permessi / reperibilità</div><div class="timeline" style="margin-top:10px">'+state.ferie.map(function(f){return '<div class="timeline-item"><div>📅</div><div style="flex:1"><div style="font-weight:700;font-size:12px">'+f.volName+' • '+f.type+' • '+fmtTime(f.ts)+'</div><div style="font-size:11px">'+f.start+' → '+f.end+' • '+f.motivo+' • '+f.status+'</div></div></div>';}).join('')+'</div></div>';
}
if(state.selectedSchedaVol){
var v=state.selectedSchedaVol;
var myTimb=state.timbrature.filter(function(t){return t.volunteerId===v.id;});
var totalMs=0;
var filtered=myTimb.filter(function(t){var d=new Date(t.ts);return d.getMonth()===state.schedaMonth && d.getFullYear()===state.schedaYear;});
for(var i=0;i<filtered.length-1;i++){if(filtered[i].type==='uscita' && filtered[i+1].type==='entrata'){totalMs+=filtered[i].ts-filtered[i+1].ts;}}
html+='<div class="modal" onclick="closeScheda()"><div class="modal-card" onclick="event.stopPropagation()"><div style="display:flex;justify-content:space-between;align-items:center"><div style="font-weight:900;font-size:18px">'+v.name+' '+(v.surname||'')+'</div><button class="btn" onclick="closeScheda()">✕</button></div><div style="font-size:11px;color:var(--text-2)">'+v.qualifica+' • '+v.gruppo+' • PIN: '+(state.revealedPins[v.id]?v.pin:'••••')+' <button class="btn" style="height:28px" onclick="togglePinReveal(\\''+v.id+'\\')">👁️</button></div><div style="display:flex;gap:8px;margin-top:10px"><select onchange="state.schedaMonth=parseInt(this.value);render()" style="flex:1;height:40px;border-radius:10px;border:1px solid var(--border);padding:0 8px">'+Array.from({length:12},function(_,i){return '<option value="'+i+'" '+(i===state.schedaMonth?'selected':'')+'>'+monthName(i)+'</option>';}).join('')+'</select><input type="number" value="'+state.schedaYear+'" onchange="state.schedaYear=parseInt(this.value);render()" style="width:90px;height:40px;border-radius:10px;border:1px solid var(--border);padding:0 8px"/></div><div style="margin-top:8px;font-size:12px">Ore: <b>'+fmtDur(totalMs)+'</b> • Timbrature mese: '+filtered.length+'</div><div style="margin-top:10px" class="calendar">'+Array.from({length:daysInMonth(state.schedaMonth,state.schedaYear)},function(_,d){var day=d+1;var has=filtered.some(function(t){return new Date(t.ts).getDate()===day;});return '<div style="height:36px;border-radius:8px;border:1px solid var(--border);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;background:'+(has?'#eef2fb':'white')+'">'+day+'</div>';}).join('')+'</div><div class="timeline" style="margin-top:10px">'+filtered.map(function(t){return '<div class="timeline-item"><div>'+(t.type==='entrata'?'🟢':t.type==='uscita'?'🔴':t.type==='emergenza'?'🚨':'✅')+'</div><div style="flex:1"><div style="font-weight:700;font-size:12px">'+t.type+' • '+fmtTime(t.ts)+'</div><div style="font-size:11px;color:var(--text-2)">'+(t.dist?Math.round(t.dist)+'m • ':'')+t.lat.toFixed(4)+','+t.lng.toFixed(4)+'</div></div></div>';}).join('')+'</div></div></div>';
}
if(state.editingVol){
var ev=state.editingVol;
html+='<div class="modal" onclick="state.editingVol=null;render()"><div class="modal-card" onclick="event.stopPropagation()"><div style="display:flex;justify-content:space-between"><div style="font-weight:900">Modifica volontario - PIN con occhio</div><button class="btn" onclick="state.editingVol=null;render()">✕</button></div><div style="display:grid;gap:8px;margin-top:12px"><input id="edit-v-name" value="'+ev.name+'" placeholder="Nome" style="height:44px;border-radius:10px;border:1px solid var(--border);padding:0 10px"/><input id="edit-v-surname" value="'+(ev.surname||'')+'" placeholder="Cognome" style="height:44px;border-radius:10px;border:1px solid var(--border);padding:0 10px"/><input id="edit-v-cf" value="'+(ev.cf||'')+'" placeholder="CF" style="height:44px;border-radius:10px;border:1px solid var(--border);padding:0 10px"/><input id="edit-v-phone" value="'+(ev.phone||'')+'" placeholder="Telefono" style="height:44px;border-radius:10px;border:1px solid var(--border);padding:0 10px"/><input id="edit-v-email" value="'+(ev.email||'')+'" placeholder="Email" style="height:44px;border-radius:10px;border:1px solid var(--border);padding:0 10px"/><select id="edit-v-qual" style="height:44px;border-radius:10px;border:1px solid var(--border);padding:0 10px">'+QUALIFICHE.map(function(q){return '<option '+(q===ev.qualifica?'selected':'')+'>'+q+'</option>';}).join('')+'</select><select id="edit-v-gruppo" style="height:44px;border-radius:10px;border:1px solid var(--border);padding:0 10px">'+GRUPPI.map(function(g){return '<option '+(g===ev.gruppo?'selected':'')+'>'+g+'</option>';}).join('')+'</select><select id="edit-v-stato" style="height:44px;border-radius:10px;border:1px solid var(--border);padding:0 10px"><option value="attivo" '+(ev.stato==='attivo'?'selected':'')+'>Attivo</option><option value="sospeso" '+(ev.stato==='sospeso'?'selected':'')+'>Sospeso</option></select><textarea id="edit-v-note" placeholder="Note" style="min-height:60px;border-radius:10px;border:1px solid var(--border);padding:8px">'+(ev.note||'')+'</textarea><div style="display:flex;gap:8px;align-items:center;background:#f8faff;border:1px solid var(--border);border-radius:10px;padding:10px"><div style="flex:1"><div style="font-size:11px;font-weight:700">PIN attuale</div><div style="font-size:18px;font-weight:900;letter-spacing:0.2em">'+(state.revealedPins[ev.id]?ev.pin:'••••')+'</div></div><button class="btn" onclick="togglePinReveal(\\''+ev.id+'\\')">👁️</button><button class="btn" onclick="copyPin(\\''+ev.pin+'\\')">📋 Copia</button><button class="btn btn-yellow" onclick="regenPin()">🔄 Rigenera</button></div><div style="display:flex;gap:8px"><button class="btn btn-green" style="flex:1" onclick="saveEditVolunteer()">💾 Salva</button><button class="btn btn-red" style="flex:1" onclick="deleteVolunteer(\\''+ev.id+'\\')">🗑️ Elimina</button></div></div></div></div>';
}
html+='</div>';
html+='<div class="bottom-nav"><button class="active">🏠<span>Home</span></button><button>📍<span>Timbra</span></button><button>📅<span>Ferie</span></button><button>💬<span>Chat</span></button><button>🏅<span>Schede</span></button></div>';
root.innerHTML=html;
}
function handleFilter(v){
state.filter=v;
render();
}
load();
render();
setInterval(function(){
if(state.emergency && state.emergency.active){
state.countdown-=1000;
if(state.countdown<=0){
triggerPosSend();
state.countdown=30000;
}
var countdownEl=document.getElementById('countdown-display');
render();
}
},1000);
(function(){
var manifest={name:'Protezione Civile Alessandria',short_name:'PC Alessandria',description:'Gruppo Comunale Protezione Civile - Città di Alessandria - Ovunque, per tutti',start_url:'.',display:'standalone',background_color:'#0f2c5c',theme_color:'#0f2c5c',icons:[{src:LOGO,sizes:'192x192',type:'image/png'},{src:LOGO,sizes:'512x512',type:'image/png'}]};
var blob=new Blob([JSON.stringify(manifest)],{type:'application/json'});
var url=URL.createObjectURL(blob);
var link=document.getElementById('manifest-link');
if(link) link.href=url;
if('serviceWorker' in navigator){
var swCode="self.addEventListener('install',function(e){self.skipWaiting()});self.addEventListener('activate',function(e){self.clients.claim()});self.addEventListener('fetch',function(e){});";
var swBlob=new Blob([swCode],{type:'text/javascript'});
var swUrl=URL.createObjectURL(swBlob);
navigator.serviceWorker.register(swUrl).catch(function(){});
}
})();
</script>
</body>
</html>`;
}

export default function App() {
  const [logoB64, setLogoB64] = useState<string | null>(null);
  const [downloading, setDownloading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [packages, setPackages] = useState<SavedPackage[]>([]);
  const [backendMsg, setBackendMsg] = useState<string>("Caricamento backend...");
  const [busy, setBusy] = useState(false);

  // REQUIRED: load saved records on startup with literal action records.list
  useEffect(() => {
    async function loadPackages() {
      try {
        // must contain literal "records.list"
        const data = await apiFetch("records.list", { collection: "pc_packages", limit: 100 });
        const recs = (data as any)?.records || data || [];
        setPackages(recs as SavedPackage[]);
        setBackendMsg(`Backend ok • ${recs.length} pacchetti salvati`);
      } catch (e) {
        setBackendMsg("Backend offline in preview (normale) - userà localStorage per GitHub Pages");
      }
    }
    loadPackages();
  }, []);

  useEffect(() => {
    let cancelled = false;
    async function toBase64() {
      try {
        if (officialLogoUrl.startsWith("data:")) {
          if (!cancelled) setLogoB64(officialLogoUrl);
          return;
        }
        const res = await fetch(officialLogoUrl);
        const blob = await res.blob();
        const reader = new FileReader();
        reader.onload = () => {
          if (!cancelled) setLogoB64(reader.result as string);
        };
        reader.readAsDataURL(blob);
      } catch {
        try {
          const img = new Image();
          img.crossOrigin = "anonymous";
          img.onload = () => {
            const c = document.createElement("canvas");
            c.width = img.width;
            c.height = img.height;
            const ctx = c.getContext("2d")!;
            ctx.drawImage(img, 0, 0);
            if (!cancelled) setLogoB64(c.toDataURL("image/png"));
          };
          img.onerror = () => {
            if (!cancelled) setLogoB64(officialLogoUrl);
          };
          img.src = officialLogoUrl;
        } catch {
          if (!cancelled) setLogoB64(officialLogoUrl);
        }
      }
    }
    toBase64();
    return () => {
      cancelled = true;
    };
  }, []);

  const reloadRecords = async () => {
    const data = await apiFetch("records.list", { collection: "pc_packages", limit: 100 });
    const recs = (data as any)?.records || data || [];
    setPackages(recs as SavedPackage[]);
  };

  const createRow = async (value: any) => {
    // REQUIRED literal records.create
    const idempotency_key = `pkg_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    await apiFetch("records.create", { collection: "pc_packages", value, idempotency_key });
  };

  const handleDownload = async () => {
    if (!logoB64) {
      alert("Logo non ancora pronto, attendi 1 secondo");
      return;
    }
    setDownloading(true);
    setBusy(true);
    try {
      const html = generateStandaloneHtml(logoB64);
      // Save to backend as record (durability)
      try {
        await createRow({
          name: "PC Alessandria index.html",
          created_at: new Date().toISOString(),
          logoSize: logoB64.length,
          sede: "44.897036,8.597517",
          radius: 150,
          motto: "Ovunque, per tutti - Presenti quando conta.",
          type: "github_pages_package",
        });
        await reloadRecords();
        setBackendMsg(`Pacchetto salvato in backend • tot ${packages.length + 1}`);
      } catch (e) {
        // preview may not have backend, ignore but show
        console.log("backend save failed in preview", e);
      }

      const blob = new Blob([html], { type: "text/html;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "index.html";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } finally {
      setDownloading(false);
      setBusy(false);
    }
  };

  const handlePreview = () => {
    if (!logoB64) return;
    const html = generateStandaloneHtml(logoB64);
    const blob = new Blob([html], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    window.open(url, "_blank");
  };

  const repoInstructions = `1. Crea repository su GitHub: es. protezione-civile-alessandria
2. Carica il file index.html scaricato nella root del repo (Upload files)
3. Vai in Settings > Pages > Branch: main, Folder: / (root) > Save
4. Attendi 1-2 minuti: il sito sarà su https://TUO-USERNAME.github.io/protezione-civile-alessandria/
5. Apri da telefono e installa come app: Android Chrome > ⋮ > Installa app / iPhone Safari > Condividi > Aggiungi a Home`;

  const copyInstructions = () => {
    try {
      const ta = document.createElement("textarea");
      ta.value = repoInstructions + "\n\nFile: index.html\nLogo embedded base64\nDati in localStorage key: pc_alessandria_github_v1\nSede: 44.897036,8.597517 raggio 150m";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {}
  };

  return (
    <div data-safe-area-inset-root style={{ boxSizing: "border-box", paddingTop: "var(--safe-area-inset-top)", minHeight: "100vh", background: "var(--bg)" }} className="w-full overflow-x-clip">
      <header data-safe-area-sticky-top style={{ top: "var(--safe-area-inset-top)" }} className="sticky z-40 backdrop-blur-xl bg-white/95 border-b border-[var(--border)] shadow-[0_2px_16px_rgba(15,44,92,0.06)] h-[60px]">
        <div className="max-w-[1100px] mx-auto px-4 h-full flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-[12px] bg-white border shadow-sm flex items-center justify-center overflow-hidden shrink-0">
              <img src={logoB64 || officialLogoUrl} alt="Logo PC" className="w-8 h-8 object-contain" />
            </div>
            <div className="min-w-0">
              <div className="font-[900] text-[12px] leading-none tracking-[0.08em] text-[var(--pc-blue)] uppercase">Pacchetto GitHub Pages - PC Alessandria</div>
              <div className="text-[11px] font-medium text-[var(--text-2)] mt-1 flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-[#0a7a42] animate-pulse" /> STATIC-FRIENDLY • localStorage • PWA • {backendMsg}</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="hidden sm:inline-flex text-[10px] px-2.5 py-1 rounded-full bg-[#eef2fb] border text-[var(--pc-blue)] font-bold">44.897036,8.597517 • 150m</span>
            <span className="text-[10px] px-2.5 py-1 rounded-full bg-[var(--pc-yellow)] text-[var(--pc-blue)] font-bold">LIVE</span>
          </div>
        </div>
      </header>

      <main className="max-w-[1100px] mx-auto px-4 py-6 pb-[40px] space-y-6">
        {/* HERO */}
        <div className="bg-[#0f2c5c] rounded-[28px] p-6 md:p-8 text-white shadow-[0_20px_60px_rgba(15,44,92,0.25)] relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_10%,#1a4a9a_0%,#0f2c5c_60%)]" />
          <div className="relative z-10 grid md:grid-cols-[1.2fr_0.8fr] gap-8 items-center">
            <div>
              <div className="inline-flex items-center gap-2 text-[10px] font-bold tracking-[0.2em] uppercase opacity-70 bg-white/10 border border-white/20 px-3 py-1 rounded-full">Protezione Civile • Città di Alessandria • Gruppo Comunale</div>
              <h1 className="mt-4 text-[28px] md:text-[36px] font-[900] leading-[0.95] tracking-tight">Pacchetto GitHub Pages<br />PC Alessandria</h1>
              <p className="mt-4 text-[15px] leading-relaxed opacity-90 max-w-[520px]">App definitiva vera mobile con logo ufficiale, senza PIN visibili, bottom navigation, timbratura 150mt da <span className="font-mono font-bold bg-white/15 px-2 py-0.5 rounded">44.897036,8.597517</span>, emergenza 30min (demo 30s), motto <em>"Ovunque, per tutti - Presenti quando conta."</em></p>
              <div className="mt-6 flex flex-wrap gap-3">
                <button onClick={handleDownload} disabled={!logoB64 || downloading || busy} className="h-[64px] px-8 rounded-[18px] bg-[var(--pc-yellow)] text-[var(--pc-blue)] font-[900] text-[16px] flex items-center gap-3 shadow-[0_8px_20px_rgba(255,204,0,0.3)] active:scale-[0.98] disabled:opacity-60">
                  <span className="w-10 h-10 rounded-full bg-[var(--pc-blue)] text-white flex items-center justify-center text-[18px]">⬇</span> Scarica index.html
                </button>
                <button onClick={handlePreview} disabled={!logoB64} className="h-[64px] px-6 rounded-[18px] bg-white/10 border border-white/20 text-white font-bold text-[14px] flex items-center gap-2 active:scale-[0.98] disabled:opacity-60">
                  👁 Anteprima live
                </button>
              </div>
              <div className="mt-4 flex flex-wrap gap-2 text-[11px]">
                <span className="px-3 py-1 rounded-full bg-white/10 border border-white/20">✅ Logo base64 embedded</span>
                <span className="px-3 py-1 rounded-full bg-white/10 border border-white/20">✅ Manifest inline</span>
                <span className="px-3 py-1 rounded-full bg-white/10 border border-white/20">✅ SW inline</span>
                <span className="px-3 py-1 rounded-full bg-white/10 border border-white/20">✅ Backend persistence</span>
                <span className="px-3 py-1 rounded-full bg-white/10 border border-white/20">📱 PWA installabile</span>
              </div>
              <div className="mt-4 text-[11px] font-mono opacity-60">Sede: Strada Casalcermelli 49C, 15121 Alessandria • {packages.length} build salvate nel backend</div>
            </div>
            <div className="bg-white rounded-[24px] p-5 text-[var(--pc-blue)] shadow-[0_20px_60px_rgba(0,0,0,0.25)]">
              <div className="flex items-center justify-between">
                <div className="font-[900] text-[13px] uppercase tracking-wide">Istruzioni 3 minuti</div>
                <button onClick={copyInstructions} className="h-8 px-3 rounded-full bg-[#eef2fb] border text-[11px] font-bold">{copied ? "✅ Copiato" : "📋 Copia"}</button>
              </div>
              <div className="mt-3 space-y-2">
                {[
                  { n: "1", t: "Scarica index.html", d: "Bottone giallo grande sopra" },
                  { n: "2", t: "Crea repo GitHub", d: "Pubblico, es. pc-alessandria" },
                  { n: "3", t: "Upload file", d: "Trascina index.html nella root" },
                  { n: "4", t: "Attiva Pages", d: "Settings > Pages > main / root" },
                  { n: "5", t: "Apri link", d: "https://USER.github.io/REPO/" },
                  { n: "6", t: "Installa PWA", d: "Aggiungi a Home da telefono" },
                ].map((s) => (
                  <div key={s.n} className="flex gap-3">
                    <div className="w-7 h-7 rounded-full bg-[var(--pc-blue)] text-white flex items-center justify-center text-[12px] font-[900] shrink-0">{s.n}</div>
                    <div>
                      <div className="font-bold text-[13px] leading-tight">{s.t}</div>
                      <div className="text-[11px] text-[var(--text-2)] leading-tight">{s.d}</div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 p-3 rounded-[12px] bg-[#f8faff] border text-[11px] leading-relaxed">
                <b>Perché questo pacchetto?</b> GitHub Pages è statico: qui hai già tutto in un file — logo in base64, manifest blob, service worker blob, localStorage per timbrature/chat, geolocalizzazione 150m, emergenza GPS. Nessun backend esterno richiesto, ma qui salviamo anche cronologia build nel backend persistente.
              </div>
              <div className="mt-3">
                <div className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-2)]">Ultimi download salvati (backend)</div>
                <div className="mt-2 space-y-1 max-h-[120px] overflow-auto">
                  {packages.slice(0,5).map((p:any)=>(
                    <div key={p.id} className="text-[11px] font-mono bg-white border rounded-[8px] p-2">{new Date(p.value.created_at).toLocaleString('it-IT')} • {p.value.name} • {(p.value.logoSize/1024).toFixed(1)}KB</div>
                  ))}
                  {packages.length===0 && <div className="text-[11px] text-[var(--text-2)]">Nessun build ancora - scarica per creare primo record</div>}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* MAIN GRID */}
        <div className="grid lg:grid-cols-[1.1fr_0.9fr] gap-6">
          {/* Phone preview mock */}
          <div className="rounded-[28px] border bg-white shadow-[0_10px_40px_rgba(15,44,92,0.08)] p-4 md:p-6">
            <div className="flex items-center justify-between">
              <div className="font-[900] text-[14px] tracking-tight">Anteprima app vera - mobile first</div>
              <div className="text-[10px] px-2 py-1 rounded-full bg-[#eef2fb] border font-bold">390px • bottom nav 84px</div>
            </div>

            <div className="mt-5 flex justify-center">
              <div className="w-[340px] max-w-full rounded-[36px] border-[10px] border-black shadow-[0_20px_60px_rgba(0,0,0,0.25)] overflow-hidden bg-[#f4f6fb] flex flex-col h-[680px]">
                {/* fake status bar */}
                <div className="h-6 bg-black text-white text-[10px] flex items-center justify-between px-4 font-mono"><span>09:41</span><span>📶 🔋</span></div>
                {/* app header */}
                <div className="h-[60px] bg-white/95 border-b flex items-center justify-between px-3 shrink-0">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-[10px] bg-white border flex items-center justify-center"><img src={logoB64 || officialLogoUrl} alt="logo" className="w-6 h-6 object-contain" /></div>
                    <div className="leading-tight"><div className="font-[900] text-[10px]">PC ALESSANDRIA</div><div className="text-[9px] text-[var(--text-2)]">44.897036,8.597517 • 150m</div></div>
                  </div>
                  <div className="text-[9px] px-2 py-1 rounded-full bg-[#eef2fb] border font-bold">ONLINE</div>
                </div>
                <div className="flex-1 overflow-auto p-3 space-y-3 bg-[#f4f6fb]">
                  <div className="rounded-[18px] bg-[#0f2c5c] text-white p-4 relative overflow-hidden">
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_10%,#1a4a9a_0%,#0f2c5c_60%)]" />
                    <div className="relative z-10">
                      <div className="flex items-center gap-2"><div className="w-8 h-8 rounded-full bg-white/15 flex items-center justify-center">🛡️</div><div className="font-[900] text-[11px] tracking-wide">Ovunque, per tutti</div></div>
                      <div className="mt-2 font-[900] text-[16px] leading-[0.95]">Presenti quando conta.</div>
                      <div className="mt-2 text-[11px] opacity-80 italic">"Ovunque, per tutti - Presenti quando conta."</div>
                      <div className="mt-3 grid grid-cols-2 gap-2">
                        <div className="rounded-[12px] bg-white/10 border border-white/15 p-2"><div className="text-[10px] opacity-70">Sede</div><div className="font-bold text-[11px] mono">Casalcermelli 49C</div></div>
                        <div className="rounded-[12px] bg-white/10 border border-white/15 p-2"><div className="text-[10px] opacity-70">Raggio</div><div className="font-bold text-[11px]">150m da HQ</div></div>
                      </div>
                      <div className="mt-3 flex gap-2">
                        <div className="flex-1 h-10 rounded-[12px] bg-[var(--pc-yellow)] text-[var(--pc-blue)] font-[900] text-[11px] flex items-center justify-center">📍 Entrata</div>
                        <div className="flex-1 h-10 rounded-[12px] bg-white/15 border border-white/20 text-white font-bold text-[11px] flex items-center justify-center">🚪 Uscita</div>
                      </div>
                      <div className="mt-2 h-10 rounded-[12px] bg-[#d61f2d] text-white font-[900] text-[11px] flex items-center justify-center">🚨 EMERGENZA</div>
                    </div>
                  </div>

                  <div className="rounded-[16px] bg-white border p-3">
                    <div className="font-bold text-[11px] flex justify-between"><span>📅 Schede mese per mese</span><span className="text-[10px] text-[var(--text-2)]">Dic 2025</span></div>
                    <div className="mt-2 grid grid-cols-7 gap-1">
                      {Array.from({ length: 14 }, (_, i) => (
                        <div key={i} className={`h-7 rounded-[8px] border flex items-center justify-center text-[10px] font-bold ${i % 5 === 0 ? "bg-[#eef2fb] text-[var(--pc-blue)]" : "bg-white"}`}>{i + 1}</div>
                      ))}
                    </div>
                    <div className="mt-2 text-[10px] text-[var(--text-2)]">Ore totali mese: <b className="text-[var(--pc-blue)]">24h 30m</b> • 12 timbrature</div>
                  </div>

                  <div className="rounded-[16px] bg-white border p-3">
                    <div className="font-bold text-[11px]">👥 Login senza PIN visibili</div>
                    <div className="mt-2 space-y-2">
                      <div className="flex gap-2 items-center bg-[#f8faff] border rounded-[10px] p-2">
                        <div className="w-8 h-8 rounded-full bg-[var(--pc-blue)] text-white flex items-center justify-center font-bold text-[12px]">MR</div>
                        <div className="flex-1 min-w-0"><div className="font-bold text-[11px]">Mario Rossi • Gruppo Comunale</div><div className="text-[10px] text-[var(--text-2)]">Operatore Base • PIN ••••</div></div>
                        <div className="w-6 h-6 rounded-full bg-white border flex items-center justify-center">🔒</div>
                      </div>
                      <div className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-2)]">🔒 PIN segreto</div>
                      <div className="h-12 rounded-[12px] border-2 border-[var(--border)] bg-[#f8faff] flex items-center justify-center text-[22px] tracking-[0.4em] font-bold">••••</div>
                      <div className="grid grid-cols-5 gap-1.5">
                        {[1,2,3,4,5].map(n => <div key={n} className="h-9 rounded-full bg-[var(--surface-2)] border flex items-center justify-center font-bold text-[12px]">{n}</div>)}
                      </div>
                      <div className="h-12 rounded-[12px] bg-[var(--pc-blue)] text-white font-[900] flex items-center justify-center gap-2 text-[13px]">✅ ENTRA IN SERVIZIO</div>
                      <div className="rounded-[10px] bg-[#eef2fb] border p-2 text-[10px] flex gap-2 leading-snug"><span>🛡️</span><span><b>Sicurezza:</b> PIN nascosti in login, visibili solo a Coord con occhio.</span></div>
                    </div>
                    <div className="text-[9px] text-[var(--text-2)] font-mono text-center mt-2">Sede Strada Casalcermelli 49C • 44.897036,8.597517 • Raggio 150m</div>
                  </div>
                </div>
                <div className="h-[84px] bg-white/95 backdrop-blur-xl border-t border-[var(--border)] flex justify-around items-center px-2 shrink-0">
                  {[
                    { l: "Home", i: "🏠", a: true },
                    { l: "Timbra", i: "📍" },
                    { l: "Ferie", i: "📅" },
                    { l: "Chat", i: "💬" },
                    { l: "Schede", i: "🏅" },
                  ].map(t => (
                    <div key={t.l} className={`flex flex-col items-center gap-1 py-2 px-2 rounded-[12px] ${t.a ? "bg-[#eef2fb] text-[var(--pc-blue)]" : "text-[var(--text-2)]"}`}>
                      <span className="text-[18px]">{t.i}</span>
                      <span className="text-[9px] font-bold">{t.l}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Details */}
          <div className="space-y-4">
            <div className="rounded-[18px] border bg-[#f8faff] p-4">
              <div className="font-bold text-[13px]">📱 Mobile-first vera app</div>
              <div className="mt-2 text-[12px] text-[var(--text-2)] leading-relaxed">
                L'app scaricata è identica all'artefatto esistente: bottom navigation 56px per guanti, header 60px sticky, logo ufficiale ovunque, motto in login e footer, timbratura normale validata 150m da sede <b>44.897036,8.597517</b>, emergenza con invio GPS ogni 30min (demo 30s), schede mese per mese con calendario, modifica volontari con foto, PIN protetti.
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2 text-[11px]">
                <div className="rounded-[10px] bg-white border p-2"><b>Timbratura</b><br />Haversine 150m • GPS high accuracy • vibrazione</div>
                <div className="rounded-[10px] bg-white border p-2"><b>Emergenza</b><br />Attiva GPS • invio automatico 30min • countdown live</div>
                <div className="rounded-[10px] bg-white border p-2"><b>Schede</b><br />Mese per mese • calendario • ore totali • export CSV/JSON</div>
                <div className="rounded-[10px] bg-white border p-2"><b>Chat</b><br />Canali generale/emergenze/coordinamento • localStorage</div>
              </div>
            </div>

            <div className="rounded-[18px] border bg-white p-4">
              <div className="font-bold text-[13px]">🛠️ Tecnico GitHub Pages + Backend</div>
              <div className="mt-2 font-mono text-[11px] leading-relaxed bg-[#f8faff] border rounded-[12px] p-3">
                <div>• File: index.html (standalone)</div>
                <div>• Logo: {logoB64 ? `base64 ${(logoB64.length / 1024).toFixed(1)}KB` : "loading..."}</div>
                <div>• Manifest: data:application/json blob URL</div>
                <div>• SW: blob URL inline, skipWaiting</div>
                <div>• Storage: localStorage key pc_alessandria_github_v1</div>
                <div>• Backend: fetch("actions") • records.list • records.create</div>
                <div>• Collection: pc_packages • idempotency_key per build</div>
                <div>• PWA installabile su Android/iOS/Desktop</div>
                <div>• Apertura: https://USERNAME.github.io/REPO/</div>
              </div>
              <button onClick={handleDownload} disabled={!logoB64 || busy} className="mt-3 w-full h-14 rounded-[14px] bg-[var(--pc-blue)] text-white font-bold text-[14px] flex items-center justify-center gap-2 active:scale-95 disabled:opacity-60">
                ⬇ Scarica index.html per GitHub Pages {busy ? "(salvo backend...)" : ""}
              </button>
            </div>

            <div className="rounded-[18px] bg-[#0f2c5c] text-white p-4">
              <div className="font-bold text-[13px]">📋 Checklist pubblicazione</div>
              <div className="mt-2 text-[12px] leading-relaxed space-y-1">
                <div>☐ Scaricato index.html con logo base64</div>
                <div>☐ Creato repo pubblico su GitHub</div>
                <div>☐ Upload index.html in root</div>
                <div>☐ Attivato Pages su main / root</div>
                <div>☐ Aperto link da telefono</div>
                <div>☐ Installato come PWA (Aggiungi a Home)</div>
                <div>☐ Testato login con PIN (es. Mario 1234, Coord 9999)</div>
                <div>☐ Testato timbratura entro 150m da sede</div>
              </div>
            </div>
          </div>
        </div>

        <div className="text-center text-[11px] text-[var(--text-2)] pb-6">
          <div className="font-bold text-[var(--pc-blue)] flex items-center justify-center gap-2"><img src={logoB64 || officialLogoUrl} alt="logo" className="w-6 h-6 object-contain" /> Protezione Civile - Città di Alessandria • Gruppo Comunale • "Ovunque, per tutti - Presenti quando conta."</div>
          <div className="mt-2 mono">Pacchetto GitHub Pages • File: index.html • Logo base64 embedded • Sede Strada Casalcermelli 49C, 15121 Alessandria • 44.897036,8.597517 • Raggio 150m • PWA fullscreen • Mobile-first 100% • Backend: fetch("actions") records.list / records.create</div>
        </div>
      </main>
    </div>
  );
}
